# Flutter 0.4.0 – gemeinsames Haushaltsrelease

Neue Seite `lib/household_page.dart`; erreichbar im Rezeptbuch über `Wochenplan, Einkauf & Vorrat` sowie das Kalender-Symbol. Es werden die bereits in `NasSyncEngine` gespeicherten 30-Tage-Anmeldedaten verwendet. Kein Datenbankpasswort und kein serverseitiger API-Schlüssel im Client.

Funktionen: Woche/Mahlzeit/Rezept/Portionen, Einkaufsbedarf und manuelle Liste mit abhakbaren Posten und Kaufbestätigung, Rohwarenchargen mit Lagerort/MHD, Korrekturbuchungen, Kochen mit Rohwarenabbuchung, fertige Portionen essen oder umlagern.

Neue Haushaltsdaten benötigen zum Schreiben eine erreichbare NAS via Tailscale; Offline-Leseansicht der zuletzt geladenen Daten. Vorhandene lokale Rezepte können weiterhin offline bearbeitet und später synchronisiert werden.

Build via GitHub Actions: `unzip -q rezept_app_flutter_prototyp_v0_4_0.zip -d source` (danach die bisherigen flutter-create/get/test/build Schritte). Ohne Flutter SDK hier nicht vorab kompiliert. Keine Browser-/Website-Daten löschen.
