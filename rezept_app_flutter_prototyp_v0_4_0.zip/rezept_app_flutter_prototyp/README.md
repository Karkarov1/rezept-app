# Rezept-App – Flutter 0.3.2 (Testversion)

**Ziel:** Ein persönliches Rezeptkonto auf NAS und mehreren Geräten.

## Änderungen gegenüber 0.3.1

- Lokale Rezepte und JSON-Backup bleiben bestehen (`rezept_app_recipes_v1`).
- Nach Anmeldung speichert der Browser einen **widerrufbaren Bearer-Sitzungsschlüssel** in `shared_preferences` und prüft Ablaufzeit; niemals NAS-API_TOKEN oder Passwort in Flutter/GitHub.
- Backend 0.4.1 erstellt neue Sitzungen für **30 Tage**. Ein alter, vor dem Server-Update ausgestellter Token behält seine ursprüngliche Dauer. Nach dem Update einmal ab- und wieder anmelden.
- Automatischer Abgleich beim Start, nach Speichern und beim Zurückkehren in die geöffnete App; bei offline/ausgeschaltetem Tailscale bleiben Änderungen lokal bis zum nächsten Anlauf.
- Drei-Wege-Vergleich mit dauerhaft gespeicherter letzter bestätigter NAS-Version pro Rezept. Wenn ausschließlich lokal editiert, aktualisiert die App automatisch per `PUT /recipes/{id}` mit `If-Match`-Revision. Falls ausschließlich NAS editiert, wird die Änderung lokal übernommen. Ist auf beiden Seiten geändert worden oder fehlt die Basis, erfolgt **kein automatisches Überschreiben**.
- Konfliktansicht: Unterschiede je Feld, explizit „Lokale Version auf NAS“ oder „NAS-Version auf Gerät“ (Bestätigung und Revisionsprüfung).
- Löschungen werden **nicht** automatisch zwischen Geräten übertragen oder rückgängig gemacht. Konflikte werden angezeigt; Lösch-Synchronisierung ist eine eigene spätere Entwicklung.
- Vorhandene Rezepte werden vor dem ersten Abgleich nicht gelöscht oder überschrieben. Bei Backup-Import wird die alte Synchronisationsbasis verworfen, damit ältere Backups nicht stillschweigend ein neueres NAS-Rezept überschreiben.

## GitHub-Deployment wie gehabt

1. Vorab ein JSON-Backup aus der App exportieren und extern aufbewahren. Keine Browser-/App-Daten löschen.
2. ZIP `rezept_app_flutter_prototyp_v0_3_2.zip` ins bestehende öffentliche GitHub-Repository laden.
3. `.github/workflows/deploy.yml` auf `unzip -q rezept_app_flutter_prototyp_v0_3_2.zip -d source` ändern, weitere Workflow-Schritte unverändert lassen.
4. Den GitHub-Actions-Build beobachten. Der Build kann Fehler zeigen, weil Flutter hier nicht verfügbar ist; nur bei grünem Build fortfahren.
5. In einem normalen Chrome-Tab `https://karkarov1.github.io/rezept-app/?v=0.3.2` öffnen. Nicht einfach die installierte alte PWA löschen.
6. Nach Backend-Update im Wolken-Menü einmal erneut anmelden und einen manuellen Abgleich ausführen. Danach app-neustart, offline/online und lokale Bearbeitung testen.

## Sicherheit und Grenzen

- `shared_preferences` im Browser nutzt clientseitigen Website-Speicher. Andere Skripte **auf derselben Web-Origin** könnten dort gespeicherte Sitzungen theoretisch lesen. Für eine private, ausschließlich über Tailscale erreichbare Einzelbenutzer-App ist das ein bewusster Komfort-Kompromiss, **kein gleichwertiger Ersatz für HttpOnly-Cookies**. Browserdaten nicht mit anderen teilen, nur vertrauenswürdigen Code unter derselben Origin hosten, bei Geräteverlust Sitzung serverseitig widerrufen.
- Kein dauerhafter Sync bei vollständig geschlossener PWA; kein Push-Dienst; kein Löschabgleich. Ein echter Offline-Sync-Motor mit atomarer Warteschlange ist noch nicht implementiert. Alle Änderungen werden im bisherigen lokalen Speicher abgelegt und beim nächsten App-Lebenszyklus-Abgleich verarbeitet; der Browser kann lokalen Speicher bei Datenlöschung/Eviction verlieren.
- Der Server gibt höchstens 500 Rezepte pro Liste aus. Bei Erreichen wird aus Sicherheitsgründen kein Abgleich durchgeführt.
- API bleibt mit Tailscale Serve nur tailnet-intern über HTTPS erreichbar; niemals `tailscale funnel` oder PostgreSQL öffentlich machen.
