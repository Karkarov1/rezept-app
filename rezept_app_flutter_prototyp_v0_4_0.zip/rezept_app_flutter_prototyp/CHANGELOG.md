## 0.3.2
- NAS-Anmeldung merken (Session, kein Passwort, keine API_TOKEN Weitergabe)
- Automatischer, vorsichtiger Abgleich beim Öffnen, Speichern und Wiederaufnehmen
- Lokale/NAS-Bearbeitungen per Revision unterscheiden
- Konflikte mit Feldunterschieden und expliziter Auswahl auflösen
- Ausstehende Löschungen nicht automatisch auf NAS oder Gerät ausführen
- Browser-JSON-Backup unverändert
