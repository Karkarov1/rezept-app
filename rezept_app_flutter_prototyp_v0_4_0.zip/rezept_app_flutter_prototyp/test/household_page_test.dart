import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:rezept_app/household_page.dart';

void main() {
  testWidgets('Haushaltstabs sind sichtbar ohne aktive NAS-Sitzung', (tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const MaterialApp(home: HouseholdPage()));
    await tester.pumpAndSettle();
    expect(find.text('Woche'), findsOneWidget);
    expect(find.text('Einkauf'), findsOneWidget);
    expect(find.text('Vorrat'), findsOneWidget);
  });
}
