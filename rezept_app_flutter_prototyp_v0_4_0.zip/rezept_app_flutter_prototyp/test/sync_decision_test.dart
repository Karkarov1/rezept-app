import 'package:flutter_test/flutter_test.dart';
import 'package:rezept_app/recipe.dart';
import 'package:rezept_app/sync_decision.dart';

Recipe dish(String title, {int revision = 1}) => Recipe(
  id: 'test', title: title, category: 'Mittagessen', basePortions: 2,
  ingredients: const [IngredientLine(foodName: 'Reis', amount: 200, unit: 'g')],
  revision: revision,
);

void main() {
  test('New recipe is uploaded, never treated as a conflict', () {
    expect(decideSync(local: dish('A'), remote: null, lastSynced: null,
      lastRevision: null), SyncDecision.uploadNew);
  });
  test('Single local edit auto-uploads only when server baseline unchanged', () {
    expect(decideSync(local: dish('B'), remote: dish('A', revision: 3),
      lastSynced: dish('A'), lastRevision: 3), SyncDecision.updateNas);
  });
  test('Single remote edit auto-downloads', () {
    expect(decideSync(local: dish('A'), remote: dish('B', revision: 4),
      lastSynced: dish('A'), lastRevision: 3), SyncDecision.updateLocal);
  });
  test('Two different edits never overwrite silently', () {
    expect(decideSync(local: dish('B'), remote: dish('C', revision: 4),
      lastSynced: dish('A'), lastRevision: 3), SyncDecision.conflict);
  });
  test('Unexpected revision bump blocks automatic update', () {
    expect(decideSync(local: dish('B'), remote: dish('A', revision: 4),
      lastSynced: dish('A'), lastRevision: 3), SyncDecision.conflict);
  });
  test('Local deletion cannot be undone by auto-download', () {
    expect(decideSync(local: null, remote: dish('A'),
      lastSynced: dish('A'), lastRevision: 3), SyncDecision.deletedLocally);
  });
  test('Deleted NAS recipe is not automatically recreated', () {
    expect(decideSync(local: dish('A'), remote: null,
      lastSynced: dish('A'), lastRevision: 3), SyncDecision.deletedRemotely);
  });
  test('Initial divergence is a conflict, not an overwrite', () {
    expect(decideSync(local: dish('A'), remote: dish('B'),
      lastSynced: null, lastRevision: null), SyncDecision.conflict);
  });
  test('Revision metadata from NAS response is retained in-memory', () {
    final restored = Recipe.fromJson({...dish('A').toJson(), 'revision': 7});
    expect(restored.revision, 7);
  });
}
