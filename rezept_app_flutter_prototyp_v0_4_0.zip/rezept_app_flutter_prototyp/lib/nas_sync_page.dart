import 'package:flutter/material.dart';

import 'nas_sync_engine.dart';

/// Account settings, status and explicit conflict decisions. Automatic sync
/// runs also when the home page opens / a recipe is locally saved.
class NasSyncPage extends StatefulWidget {
  const NasSyncPage({super.key, required this.engine, required this.onDataChanged});
  final NasSyncEngine engine;
  final Future<void> Function() onDataChanged;

  @override
  State<NasSyncPage> createState() => _NasSyncPageState();
}

class _NasSyncPageState extends State<NasSyncPage> {
  final _address = TextEditingController();
  final _username = TextEditingController();
  final _password = TextEditingController();
  SavedNasSession? _session;
  NasSyncReport? _report;
  bool _busy = false;
  String? _message;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _restore();
  }

  Future<void> _restore() async {
    final session = await widget.engine.savedSession();
    final url = session?.address ?? await widget.engine.suggestedAddress();
    if (!mounted) return;
    setState(() {
      _session = session;
      _address.text = url;
      _username.text = session?.username ?? '';
    });
  }

  @override
  void dispose() {
    _address.dispose();
    _username.dispose();
    _password.dispose();
    super.dispose();
  }

  void _notice(String text, {bool error = false}) {
    if (!mounted) return;
    setState(() { _message = text; _failed = error; });
  }

  Future<void> _login() async {
    if (_busy) return;
    setState(() { _busy = true; _message = null; });
    try {
      final session = await widget.engine.login(_address.text, _username.text, _password.text);
      _password.clear();
      if (!mounted) return;
      setState(() => _session = session);
      await _sync();
    } catch (e) {
      _notice('Anmeldung fehlgeschlagen: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _sync() async {
    // Also called during login while the progress indicator is already active.
    try {
      final report = await widget.engine.synchronize();
      await widget.onDataChanged();
      if (!mounted) return;
      setState(() => _report = report);
      _notice('Abgleich abgeschlossen: ${report.uploaded} neu zur NAS, '
          '${report.updated} aktualisiert, ${report.downloaded} aufs Gerät, '
          '${report.identical} identisch, ${report.conflicts.length} Konflikte.');
    } catch (e) {
      _notice('Synchronisierung derzeit nicht möglich: $e. Lokale Rezepte bleiben erhalten.', error: true);
    }
  }

  Future<void> _syncPressed() async {
    if (_busy) return;
    setState(() { _busy = true; _message = null; });
    try { await _sync(); } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _resolve(NasSyncConflict conflict, bool keepLocal) async {
    if (_busy) return;
    final approved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Rezeptkonflikt auflösen?'),
        content: Text(keepLocal
          ? '„${conflict.title}“: Die NAS-Version wird durch deine lokale Fassung ersetzt. '
            'Die Änderung wird nur bei noch unveränderter NAS-Revisionsnummer übernommen.'
          : '„${conflict.title}“: Die lokale Fassung wird durch die NAS-Version ersetzt. '
            'Bitte vorher ein JSON-Backup deiner lokalen Rezepte erstellen.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Abbrechen')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Änderung bestätigen')),
        ],
      ),
    );
    if (approved != true || !mounted) return;
    setState(() { _busy = true; _message = null; });
    try {
      await widget.engine.resolveConflict(conflict, keepLocal: keepLocal);
      await widget.onDataChanged();
      await _sync();
      _notice('Konflikt aufgelöst. NAS und Gerät wurden erneut verglichen.');
    } catch (e) {
      _notice('Konflikt nicht verändert: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _logout() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await widget.engine.logout();
      if (!mounted) return;
      setState(() { _session = null; _report = null; });
      _notice('Abgemeldet. Anmeldung auf diesem Gerät entfernt.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Synology-Synchronisierung')),
    body: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 640),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('NAS-Verbindung', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            const Text('Tailscale ist für die Synchronisierung notwendig. Die Anmeldung '
              'wird auf diesem Gerät bis zum Ablauf der Serversitzung gespeichert. '
              'Lokal funktionieren die Rezepte auch offline.'),
            const SizedBox(height: 20),
            if (_session == null) ...[
              TextField(controller: _address, keyboardType: TextInputType.url,
                autocorrect: false, decoration: const InputDecoration(labelText: 'NAS-Adresse (HTTPS)')),
              const SizedBox(height: 12),
              TextField(controller: _username, autocorrect: false,
                decoration: const InputDecoration(labelText: 'Benutzername')),
              const SizedBox(height: 12),
              TextField(controller: _password, obscureText: true,
                decoration: const InputDecoration(labelText: 'Passwort'),
                onSubmitted: (_) => _login()),
              const SizedBox(height: 16),
              FilledButton.icon(onPressed: _busy ? null : _login,
                icon: const Icon(Icons.login), label: const Text('Anmelden (30 Tage)')),
            ] else ...[
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.verified_user_outlined),
                title: Text('Angemeldet: ${_session!.username}'),
                subtitle: Text('${_session!.address}\nSitzung gültig bis ${_session!.expiresAt.toLocal().day}.${_session!.expiresAt.toLocal().month}.${_session!.expiresAt.toLocal().year}'),
                isThreeLine: true,
                trailing: TextButton(onPressed: _busy ? null : _logout, child: const Text('Abmelden')),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(onPressed: _busy ? null : _syncPressed,
                icon: const Icon(Icons.sync), label: const Text('Jetzt synchronisieren')),
              if (_report != null) ...[
                const SizedBox(height: 16),
                Card(child: Padding(padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${_report!.identical} identische Rezepte'),
                    Text('${_report!.uploaded} neue Rezepte zur NAS übertragen'),
                    Text('${_report!.updated} Rezepte auf der NAS aktualisiert'),
                    Text('${_report!.downloaded} Rezepte aufs Gerät übernommen'),
                    Text('${_report!.conflicts.length} Konflikte (nicht überschrieben)'),
                    if (_report!.pendingDeletions > 0)
                      Text('${_report!.pendingDeletions} lokal gelöschte Rezepte noch auf NAS'),
                    if (_report!.conflicts.isNotEmpty) ...[
                      const SizedBox(height: 14),
                      const Text('Unterschiede und Konfliktauflösung:',
                        style: TextStyle(fontWeight: FontWeight.w600)),
                      for (final conflict in _report!.conflicts)
                        ExpansionTile(
                          title: Text(conflict.title),
                          subtitle: Text('${conflict.differences.length} Abweichungen'),
                          children: [
                            for (final diff in conflict.differences)
                              ListTile(dense: true, title: Text(diff)),
                            if (conflict.canChoose) ...[
                              TextButton.icon(onPressed: _busy ? null : () => _resolve(conflict, true),
                                icon: const Icon(Icons.cloud_upload_outlined),
                                label: const Text('Lokales Rezept auf NAS übernehmen')),
                              TextButton.icon(onPressed: _busy ? null : () => _resolve(conflict, false),
                                icon: const Icon(Icons.download_outlined),
                                label: const Text('NAS-Version lokal übernehmen')),
                            ],
                          ],
                        ),
                    ],
                  ]))),
              ],
            ],
            if (_busy) ...[const SizedBox(height: 16), const LinearProgressIndicator()],
            if (_message != null) ...[
              const SizedBox(height: 16),
              Text(_message!, style: TextStyle(color: _failed ? Theme.of(context).colorScheme.error : null)),
            ],
            const SizedBox(height: 24),
            const Text('Synchronisation beim Öffnen, Speichern und beim Zurückwechseln zur App. '
              'Bei vollständig geschlossener Web-App oder ohne Tailscale kein Hintergrundabgleich. '
              'Echte Konflikte und Löschungen werden nicht automatisch überschrieben. '
              'Vor dem Auflösen von Konflikten JSON-Backup erstellen.',
              style: TextStyle(fontSize: 12)),
          ],
        ),
      ),
    ),
  );
}
