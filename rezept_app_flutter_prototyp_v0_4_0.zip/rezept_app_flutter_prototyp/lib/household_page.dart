import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'nas_api.dart';
import 'nas_sync_engine.dart';
import 'recipe.dart';
import 'recipe_store.dart';

/// Week planning + shopping + pantry. Uses existing Tailscale-only API and user
/// session. Reads may be cached offline; writes are only acknowledged by NAS.
/// Inventory mutations persist their operation UUID until successfully confirmed
/// so retrying after a network timeout cannot double-book a purchase/cooking.
class HouseholdPage extends StatefulWidget {
  const HouseholdPage({super.key});

  @override
  State<HouseholdPage> createState() => _HouseholdPageState();
}

class _HouseholdPageState extends State<HouseholdPage> {
  static const _pendingKey = 'rezept_household_pending_operation_v1';
  static const _cachePrefix = 'rezept_household_cache_v1_';
  static const _meals = ['Frühstück', 'Mittagessen', 'Abendessen', 'Snack'];
  static const _locations = ['Vorrat', 'Kühlschrank', 'Gefrierfach', 'Sonstiges'];
  static const _units = ['g', 'ml', 'pcs'];

  final NasSyncEngine _sync = NasSyncEngine();
  NasApiClient? _api;
  List<Recipe> _recipes = [];
  Map<String, dynamic>? _snapshot;
  DateTime _week = _monday(DateTime.now());
  bool _loading = true;
  bool _cached = false;
  String? _message;
  bool _pending = false;

  static DateTime _monday(DateTime d) =>
      DateTime(d.year, d.month, d.day).subtract(Duration(days: d.weekday - 1));
  static String _date(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  static String _quantity(Object? value) {
    if (value is num) {
      if (value % 1 == 0) return value.toStringAsFixed(0);
      return value.toStringAsFixed(3).replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
    }
    return '$value';
  }
  static List<Map<String, dynamic>> _list(Object? value) =>
      (value is List ? value : const [])
          .map((e) => Map<String, dynamic>.from(e as Map)).toList();

  static String _newUuid() {
    final random = Random.secure();
    final b = List<int>.generate(16, (_) => random.nextInt(256));
    b[6] = (b[6] & 15) | 64;
    b[8] = (b[8] & 63) | 128;
    String h(int i) => b[i].toRadixString(16).padLeft(2, '0');
    return '${h(0)}${h(1)}${h(2)}${h(3)}-${h(4)}${h(5)}-${h(6)}${h(7)}-${h(8)}${h(9)}-${h(10)}${h(11)}${h(12)}${h(13)}${h(14)}${h(15)}';
  }

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  @override
  void dispose() {
    _api?.close();
    super.dispose();
  }

  Future<void> _initialize() async {
    _recipes = await RecipeStore().load();
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('$_cachePrefix${_date(_week)}');
    if (raw != null) {
      try {
        _snapshot = Map<String, dynamic>.from(jsonDecode(raw) as Map);
        _cached = true;
      } catch (_) {}
    }
    _pending = prefs.containsKey(_pendingKey);
    final session = await _sync.savedSession();
    if (!mounted) return;
    if (session == null) {
      setState(() {
        _loading = false;
        _message = 'Bitte zuerst über das Wolkensymbol im Rezeptbuch anmelden.';
      });
      return;
    }
    _api = NasApiClient(session.address)..restoreToken(session.token);
    await _refresh();
  }

  Future<void> _refresh() async {
    if (_api == null) return;
    setState(() { _loading = true; _message = null; });
    try {
      final result = await _api!.householdGet('bootstrap?weekStart=${_date(_week)}');
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('$_cachePrefix${_date(_week)}', jsonEncode(result));
      if (mounted) setState(() { _snapshot = result; _cached = false; });
    } catch (e) {
      if (mounted) setState(() { _cached = _snapshot != null; _message = 'NAS nicht erreichbar: $e'; });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _notice(String message) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _command(Future<dynamic> Function(NasApiClient api) send) async {
    final api = _api;
    if (api == null) { _notice('Bitte zuerst am NAS-Konto anmelden.'); return; }
    try {
      await send(api);
      await _refresh();
    } catch (e) { _notice('Änderung nicht bestätigt: $e'); }
  }

  Future<void> _idempotent(String path, Map<String, dynamic> data) async {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.containsKey(_pendingKey)) {
      _notice('Zuerst den offenen Vorgang wiederholen oder bewusst verwerfen.');
      setState(() => _pending = true);
      return;
    }
    final payload = Map<String, dynamic>.from(data)..['operationId'] = _newUuid();
    await prefs.setString(_pendingKey, jsonEncode({'path': path, 'body': payload}));
    if (mounted) setState(() => _pending = true);
    await _retryPending();
  }

  Future<void> _retryPending() async {
    final api = _api;
    if (api == null) { _notice('Keine aktive NAS-Sitzung'); return; }
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_pendingKey);
    if (raw == null) { if (mounted) setState(() => _pending = false); return; }
    try {
      final pending = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      await api.householdPost(pending['path'] as String,
          Map<String, dynamic>.from(pending['body'] as Map));
      await prefs.remove(_pendingKey);
      if (mounted) setState(() => _pending = false);
      await _refresh();
      _notice('Buchung erfolgreich auf der NAS gespeichert.');
    } catch (e) {
      _notice('Buchung nicht bestätigt: $e. Du kannst sie mit derselben ID wiederholen.');
    }
  }

  Future<void> _discardPending() async {
    final yes = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Offenen Vorgang verwerfen?'),
      content: const Text('Wenn die NAS den Vorgang bereits verarbeitet hat, bleibt die Buchung bestehen. Vor erneutem Einkaufen oder Kochen deshalb den Bestand prüfen.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Zurück')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Verwerfen'))],
    ));
    if (yes != true) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_pendingKey);
    if (mounted) setState(() => _pending = false);
    await _refresh();
  }

  Future<bool> _confirm(String title, String content) async => await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(title: Text(title), content: Text(content), actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Abbrechen')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Bestätigen')),
        ]),
      ) ?? false;

  Future<void> _addPlan() async {
    if (_recipes.isEmpty) { _notice('Bitte zuerst ein Rezept anlegen.'); return; }
    var recipeId = _recipes.first.id;
    var meal = 'Mittagessen';
    var source = 'cook';
    var date = _week;
    final portion = TextEditingController(text: '2');
    final value = await showDialog<Map<String, dynamic>>(context: context, builder: (ctx) => StatefulBuilder(
      builder: (ctx, change) => AlertDialog(
        title: const Text('Mahlzeit einplanen'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          DropdownButtonFormField<String>(value: recipeId, isExpanded: true,
            decoration: const InputDecoration(labelText: 'Rezept'),
            items: _recipes.map((r) => DropdownMenuItem(value: r.id,child: Text(r.title, overflow: TextOverflow.ellipsis))).toList(),
            onChanged: (v) { if (v != null) change(() => recipeId = v); }),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(value: meal,
            decoration: const InputDecoration(labelText: 'Mahlzeit'),
            items: _meals.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
            onChanged: (v) { if (v != null) change(() => meal = v); }),
          const SizedBox(height: 12),
          TextField(controller: portion, keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Portionen')),
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: () async {
            final picked = await showDatePicker(context: ctx, initialDate: date,
              firstDate: DateTime(2020), lastDate: DateTime(2100));
            if (picked != null) change(() => date = picked);
          }, icon: const Icon(Icons.event), label: Text(_date(date))),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(value: source,
            decoration: const InputDecoration(labelText: 'Art der Mahlzeit'),
            items: const [DropdownMenuItem(value:'cook',child:Text('Neu kochen')),
              DropdownMenuItem(value:'prepared',child:Text('Reste essen (kein Rohwarenbedarf)'))],
            onChanged: (v) { if (v != null) change(() => source = v); }),
        ])),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Abbrechen')),
          FilledButton(onPressed: () {
            final n = int.tryParse(portion.text.trim());
            if (n == null || n < 1 || n > 100) return;
            Navigator.pop(ctx, {'plannedOn':_date(date),'mealType':meal,
              'recipeId':recipeId,'portions':n,'source':source});
          },child:const Text('Einplanen'))],
      ),
    ));
    portion.dispose();
    if (value != null) await _command((api) => api.householdPost('plans', value));
  }

  Future<Map<String, dynamic>?> _ingredientDialog({bool withExpiry=true}) async {
    final food = TextEditingController();
    final amount = TextEditingController();
    var unit = 'g';var location = 'Vorrat';DateTime? expiry;
    final result = await showDialog<Map<String, dynamic>>(context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, change) => AlertDialog(
        title: const Text('Lebensmittel erfassen'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: food, decoration: const InputDecoration(labelText:'Lebensmittelname')),
          const SizedBox(height: 12),
          TextField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal:true),
            decoration: const InputDecoration(labelText:'Menge')),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(value: unit, decoration:const InputDecoration(labelText:'Einheit'),
            items:_units.map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),
            onChanged:(v){if(v!=null)change(()=>unit=v);}),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(value: location, decoration:const InputDecoration(labelText:'Lagerort'),
            items:_locations.map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),
            onChanged:(v){if(v!=null)change(()=>location=v);}),
          if (withExpiry) TextButton.icon(icon:const Icon(Icons.event),
            label:Text(expiry==null?'Haltbarkeit (optional)':_date(expiry!)),onPressed:() async {
              final picked=await showDatePicker(context:ctx,initialDate:DateTime.now(),
                firstDate:DateTime(2020),lastDate:DateTime(2100));
              if(picked!=null)change(()=>expiry=picked);
            }),
        ])),
        actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Abbrechen')),
          FilledButton(onPressed:(){
            final n=double.tryParse(amount.text.replaceAll(',','.'));
            if(food.text.trim().isEmpty || n==null || !n.isFinite || n<=0)return;
            Navigator.pop(ctx,{'foodName':food.text.trim(),'amount':n,'unit':unit,
              'location':location,'expiresOn':expiry==null?null:_date(expiry!)});
          },child:const Text('Übernehmen'))],
      )));
    food.dispose();amount.dispose();return result;
  }

  Future<void> _addStock() async {
    final value=await _ingredientDialog();
    if(value!=null)await _idempotent('pantry/receive',{'lines':[value]});
  }

  Future<void> _addManual() async {
    final food=TextEditingController();final amount=TextEditingController();var unit='g';
    final data=await showDialog<Map<String,dynamic>>(context:context,builder:(ctx)=>StatefulBuilder(
      builder:(ctx,change)=>AlertDialog(title:const Text('Zur Einkaufsliste hinzufügen'),
        content:Column(mainAxisSize:MainAxisSize.min,children:[
          TextField(controller:food,decoration:const InputDecoration(labelText:'Artikel')),
          const SizedBox(height:12),
          TextField(controller:amount,keyboardType:const TextInputType.numberWithOptions(decimal:true),
            decoration:const InputDecoration(labelText:'Menge')),
          const SizedBox(height:12),
          DropdownButtonFormField<String>(value:unit,items:_units.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),
            onChanged:(v){if(v!=null)change(()=>unit=v);}),
        ]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Abbrechen')),
          FilledButton(onPressed:(){
            final n=double.tryParse(amount.text.replaceAll(',','.'));
            if(food.text.trim().isNotEmpty && n!=null && n>0 && n.isFinite)
              Navigator.pop(ctx,{'itemName':food.text.trim(),'weekStart':_date(_week),'amount':n,'unit':unit});
          },child:const Text('Hinzufügen'))] )));
    food.dispose();amount.dispose();
    if(data!=null)await _command((api)=>api.householdPost('shopping/manual',data));
  }

  Future<void> _buyChecked() async {
    final selected=_list(_snapshot?['shopping']).where((x)=>x['checked']==true).toList();
    if(selected.isEmpty){_notice('Zuerst die gekauften Artikel abhaken.');return;}
    final location=await showDialog<String>(context:context,builder:(ctx)=>SimpleDialog(
      title:const Text('Lagerort für diese Einkäufe'),
      children:_locations.map((x)=>SimpleDialogOption(onPressed:()=>Navigator.pop(ctx,x),child:Text(x))).toList(),
    ));
    if(location==null)return;
    if(!await _confirm('Einkauf bestätigen',
      '${selected.length} Artikel als tatsächlich gekauft buchen? Es werden nur die angezeigten Mengen erfasst.'))return;
    final lines=selected.map((x)=>{'foodName':x['foodName'],'amount':x['toBuy'],
      'unit':x['unit'],'location':location,'expiresOn':null}).toList();
    final manualIds=selected.where((x)=>x['manual']==true)
        .map((x)=>(x['key'] as String).substring(7)).toList();
    await _idempotent('purchases/confirm',{'lines':lines,'manualItemIds':manualIds,
      'weekStart':_date(_week),'checkedItemKeys':selected.map((x)=>x['key']).toList()});
    // Manuelle Einträge bleiben absichtlich erhalten, bis sie gezielt gelöscht werden.
  }

  Future<void> _cook(Map<String,dynamic> plan) async {
    if (!await _confirm('Kochen bestätigen',
      '${plan['recipeTitle']} – ${plan['portions']} Portionen. Rohzutaten werden jetzt abgebucht, fertige Portionen angelegt.')) return;
    await _idempotent('cooking/complete',{'planId':plan['id'],'location':'Kühlschrank','expiresOn':null});
  }

  Future<void> _eat(Map<String,dynamic> batch) async {
    final count=TextEditingController(text:'1');
    final n=await showDialog<int>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Portionen essen'),
      content:TextField(controller:count,keyboardType:TextInputType.number,
        decoration:InputDecoration(labelText:'Portionen (max. ${batch['portions']})')),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Abbrechen')),
        FilledButton(onPressed:(){final v=int.tryParse(count.text);
          if(v!=null && v>0 && v <= (batch['portions'] as num))Navigator.pop(ctx,v);
        },child:const Text('Verbrauchen'))],
    ));
    count.dispose();
    if(n!=null)await _idempotent('prepared/eat',{'batchId':batch['id'],'portions':n});
  }

  Future<void> _movePrepared(Map<String,dynamic> batch) async {
    var location='Gefrierfach';
    final count=TextEditingController(text:'1');
    final result=await showDialog<Map<String,dynamic>>(context:context,builder:(ctx)=>StatefulBuilder(
      builder:(ctx,change)=>AlertDialog(title:const Text('Fertige Portionen umlagern'),
        content:Column(mainAxisSize:MainAxisSize.min,children:[
          TextField(controller:count,keyboardType:TextInputType.number,
            decoration:InputDecoration(labelText:'Portionen (max. ${batch['portions']})')),
          const SizedBox(height:12),
          DropdownButtonFormField<String>(value:location,
            items:_locations.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),
            onChanged:(v){if(v!=null)change(()=>location=v);}),
        ]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Abbrechen')),
          FilledButton(onPressed:(){final n=int.tryParse(count.text);
            if(n!=null && n>0 && n <= (batch['portions'] as num))
              Navigator.pop(ctx,{'batchId':batch['id'],'portions':n,'location':location});
          },child:const Text('Umlagern'))],
      )));
    count.dispose();
    if(result!=null)await _idempotent('prepared/move',result);
  }

  Future<void> _adjust(Map<String,dynamic> lot) async {
    final amount=TextEditingController(text:'0');
    final n=await showDialog<double>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Bestand korrigieren'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        Text('Aktuell ${_quantity(lot['quantity'])} ${lot['unit']}; Vorzeichen + oder − eingeben.'),
        const SizedBox(height:12),
        TextField(controller:amount,keyboardType:const TextInputType.numberWithOptions(signed:true,decimal:true),
          decoration:const InputDecoration(labelText:'Änderung (+/-)')),
      ]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Abbrechen')),
        FilledButton(onPressed:(){final v=double.tryParse(amount.text.replaceAll(',','.'));
          if(v!=null && v!=0 && v.isFinite)Navigator.pop(ctx,v);
        },child:const Text('Buchen'))],
    ));
    amount.dispose();
    if(n!=null && await _confirm('Bestand korrigieren',
       '${_quantity(n)} ${lot['unit']} für ${lot['foodName']} buchen?')) {
      await _idempotent('pantry/adjust',{'lotId':lot['id'],'delta':n});
    }
  }

  Widget _headerActions() => Column(children:[
    if(_pending) Card(color:Theme.of(context).colorScheme.errorContainer,child:Padding(
      padding:const EdgeInsets.all(12),child:Column(children:[
        const Text('Ein Vorgang ist noch nicht bestätigt. Nicht mit neuer Vorgangs-ID wiederholen.'),
        Wrap(spacing:8,children:[
          TextButton.icon(onPressed:_retryPending,icon:const Icon(Icons.refresh),label:const Text('Mit gleicher ID wiederholen')),
          TextButton(onPressed:_discardPending,child:const Text('Bewusst verwerfen')),
        ])
      ]))),
    if(_cached) const ListTile(leading:Icon(Icons.wifi_off),
      title:Text('Offline-Kopie – nur lesen'),subtitle:Text('Plan, Einkauf und Vorrat können erst bei NAS-Verbindung geändert werden.')),
    if(_message!=null) Padding(padding:const EdgeInsets.all(10),child:Text(_message!)),
  ]);

  Widget _planTab() {
    final plans=_list(_snapshot?['plans']);
    return ListView(padding:const EdgeInsets.all(14),children:[
      _headerActions(),
      Row(children:[
        IconButton(onPressed:(){setState(()=>_week=_week.subtract(const Duration(days:7)));_refresh();},
          icon:const Icon(Icons.chevron_left)),
        Expanded(child:Text('Woche ab ${_date(_week)}',textAlign:TextAlign.center,
          style:Theme.of(context).textTheme.titleMedium)),
        IconButton(onPressed:(){setState(()=>_week=_week.add(const Duration(days:7)));_refresh();},
          icon:const Icon(Icons.chevron_right)),
      ]),
      FilledButton.icon(onPressed:_cached||_api==null?null:_addPlan,
        icon:const Icon(Icons.add),label:const Text('Mahlzeit einplanen')),
      const SizedBox(height:12),
      if(plans.isEmpty)const ListTile(title:Text('Noch keine Mahlzeiten geplant.')),
      for(final plan in plans)Card(child:Padding(padding:const EdgeInsets.all(12),
        child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('${plan['plannedOn']} · ${plan['mealType']}',style:Theme.of(context).textTheme.labelLarge),
          const SizedBox(height:4),
          Text('${plan['recipeTitle']} · ${plan['portions']} Portionen'),
          Text(plan['source']=='prepared'?'Reste: kein neuer Rohwarenbedarf':
            plan['status']=='cooked'?'Gekocht und Bestand gebucht':'Neu kochen – Zutaten erst bei Bestätigung abbuchen',
            style:Theme.of(context).textTheme.bodySmall),
          Wrap(spacing:8,children:[
            if(plan['source']=='cook' && plan['status']=='planned')
              TextButton.icon(onPressed:_cached?null:()=>_cook(plan),
                icon:const Icon(Icons.restaurant),label:const Text('Gekocht')),
            if(plan['status']=='planned')
              TextButton.icon(onPressed:_cached?null:()async{
                if(await _confirm('Plan entfernen','Diese Planung entfernen? Es wird kein Bestand verändert.')){
                  await _command((api)=>api.householdDelete('plans/${plan['id']}'));
                }
              },icon:const Icon(Icons.delete_outline),label:const Text('Entfernen')),
          ])
        ]))),
      const SizedBox(height:20),
      const Text('Nur ein bestätigter Kochvorgang verändert den Vorrat. Eine Planung allein bucht nichts ab.'),
    ]);
  }

  Widget _shoppingTab() {
    final items=_list(_snapshot?['shopping']);
    return ListView(padding:const EdgeInsets.all(14),children:[
      _headerActions(),
      Text('Einkaufsliste für ${_date(_week)}',style:Theme.of(context).textTheme.titleMedium),
      const SizedBox(height:10),
      OutlinedButton.icon(onPressed:_cached?null:_addManual,icon:const Icon(Icons.add),
        label:const Text('Artikel manuell ergänzen')),
      if(items.isEmpty)const ListTile(title:Text('Nichts einzukaufen.')),
      for(final item in items)Card(child:Column(children:[
        CheckboxListTile(value:item['checked']==true,onChanged:_cached?null:(v) async {
          await _command((api)=>api.householdPut('shopping/check',{
            'weekStart':_date(_week),'itemKey':item['key'],'checked':v==true}));
        },title:Text('${item['foodName']} – ${_quantity(item['toBuy'])} ${item['unit']}'),
          subtitle:Text(item['manual']==true?'Manuell':item['stockKnown']==false?
            'Vorrat unbekannt – Menge vor Einkauf prüfen':
            'Bedarf: ${_quantity(item['needed'])}, vorhanden: ${_quantity(item['inStock'])}'),
          controlAffinity:ListTileControlAffinity.leading),
        if(item['manual']==true)Align(alignment:Alignment.centerRight,child:TextButton(
          onPressed:_cached?null:() => _command((api)=>api.householdDelete(
            'shopping/manual/${(item['key'] as String).substring(7)}')),
          child:const Text('Manuellen Artikel entfernen'))),
      ])),
      const SizedBox(height:12),
      FilledButton.icon(onPressed:_cached||_pending?null:_buyChecked,
        icon:const Icon(Icons.shopping_bag_outlined),label:const Text('Abgehakten Einkauf bestätigen')),
      const SizedBox(height:12),
      const Text('Abhaken allein verändert keine Bestände. Erst „Einkauf bestätigen“ bucht die Mengen. Unbekannten Vorrat bitte zuvor kontrollieren.'),
    ]);
  }

  Widget _pantryTab() {
    final lots=_list(_snapshot?['pantry']);
    final prepared=_list(_snapshot?['prepared']);
    return ListView(padding:const EdgeInsets.all(14),children:[
      _headerActions(),
      Text('Lebensmittelvorrat',style:Theme.of(context).textTheme.titleMedium),
      const SizedBox(height:12),
      OutlinedButton.icon(onPressed:_cached||_pending?null:_addStock,
        icon:const Icon(Icons.add),label:const Text('Bestand erfassen')),
      if(lots.isEmpty)const ListTile(title:Text('Noch keine Rohwaren erfasst. Ohne Bestandserfassung kann Kochen nicht abgebucht werden.')),
      for(final lot in lots)Card(child:ListTile(
        title:Text('${lot['foodName']} · ${_quantity(lot['quantity'])} ${lot['unit']}'),
        subtitle:Text('${lot['location']}${lot['expiresOn']!=null?' · MHD ${lot['expiresOn']}':''}'),
        trailing:IconButton(icon:const Icon(Icons.edit),tooltip:'Bestand korrigieren',
          onPressed:_cached||_pending?null:()=>_adjust(lot)),
      )),
      const SizedBox(height:20),
      Text('Fertig gekochte Portionen',style:Theme.of(context).textTheme.titleMedium),
      if(prepared.isEmpty)const ListTile(title:Text('Noch keine fertigen Portionen vorhanden.')),
      for(final batch in prepared)Card(child:ListTile(
        title:Text('${batch['recipeTitle']} · ${batch['portions']} Portionen'),
        subtitle:Text('${batch['location']}${batch['expiresOn']!=null?' · MHD ${batch['expiresOn']}':''}'),
        trailing:Wrap(mainAxisSize:MainAxisSize.min,children:[
          IconButton(tooltip:'Portionen umlagern / einfrieren',
            onPressed:_cached||_pending?null:()=>_movePrepared(batch),
            icon:const Icon(Icons.ac_unit)),
          TextButton(onPressed:_cached||_pending?null:()=>_eat(batch),child:const Text('Gegessen')),
        ]),
      )),
      const SizedBox(height:12),
      const Text('„Gegessen“ reduziert nur fertige Portionen. Rohwaren wurden bereits beim Kochen abgebucht.'),
    ]);
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(length:3, child:Scaffold(
    appBar:AppBar(title:const Text('Haushaltsplanung'),actions:[
      IconButton(tooltip:'NAS-Daten aktualisieren',onPressed:_refresh,icon:const Icon(Icons.refresh)),
    ],bottom:const TabBar(tabs:[Tab(text:'Woche',icon:Icon(Icons.calendar_month)),
      Tab(text:'Einkauf',icon:Icon(Icons.shopping_cart_outlined)),
      Tab(text:'Vorrat',icon:Icon(Icons.inventory_2_outlined))])),
    body: _snapshot==null
      ? Center(child:_loading?const CircularProgressIndicator():
          Text(_message??'Keine Daten verfügbar. Melde dich über das Wolkensymbol an.'))
      : Column(children:[
          if(_loading)const LinearProgressIndicator(minHeight:2),
          Expanded(child:TabBarView(children:[_planTab(),_shoppingTab(),_pantryTab()])),
        ]),
  ));
}
