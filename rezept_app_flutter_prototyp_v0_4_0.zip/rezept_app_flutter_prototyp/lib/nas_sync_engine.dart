import 'dart:async';
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'nas_api.dart';
import 'recipe.dart';
import 'recipe_store.dart';
import 'sync_plan.dart';
import 'sync_decision.dart';

/// Local browser storage can be read by scripts running on the same origin.
/// NEVER use the server's API_TOKEN here; only a revocable user session token.
/// Tailscale / HTTPS is still required for all API requests.
class SavedNasSession {
  const SavedNasSession(this.address, this.username, this.token, this.expiresAt);
  final String address;
  final String username;
  final String token;
  final DateTime expiresAt;

  bool get expired => !expiresAt.isAfter(DateTime.now().toUtc());
}

class NasSyncConflict {
  const NasSyncConflict({required this.id, required this.title, required this.differences,
    this.local, this.remote});
  final String id;
  final String title;
  final List<String> differences;
  final Recipe? local;
  final Recipe? remote;

  bool get canChoose => local != null && remote != null;
}

class NasSyncReport {
  const NasSyncReport({this.uploaded = 0, this.downloaded = 0, this.updated = 0,
    this.identical = 0, this.conflicts = const [], this.pendingDeletions = 0});
  final int uploaded;
  final int downloaded;
  final int updated;
  final int identical;
  final int pendingDeletions;
  final List<NasSyncConflict> conflicts;

  bool get clean => conflicts.isEmpty;
}

class _Baseline {
  const _Baseline({required this.recipe, required this.revision});
  final Recipe recipe;
  final int revision;
  Map<String, dynamic> toJson() => {'recipe': recipe.toJson(), 'revision': revision};

  static _Baseline fromJson(Object? item) {
    if (item is! Map) throw const FormatException('Ungültiger NAS-Synchronisationsstand');
    return _Baseline(recipe: Recipe.fromJson(Map<String, dynamic>.from(item['recipe'] as Map)),
      revision: (item['revision'] as num).toInt());
  }
}

/// Serializes automatic and manual syncs, including conflict decisions.
/// All changes are saved locally. No recipe is automatically deleted.
class NasSyncEngine {
  static const _sessionKey = 'rezept_app_nas_session_v032';
  static const _baselineKey = 'rezept_app_nas_baseline_v032';
  static const _baselineOwnerKey = 'rezept_app_nas_baseline_owner_v032';
  static const _legacyAddressKey = 'rezept_app_nas_url_v1';
  final RecipeStore _store = RecipeStore();
  Future<NasSyncReport>? _inFlight;

  Future<String> suggestedAddress() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_legacyAddressKey) ?? '';
  }

  Future<SavedNasSession?> savedSession() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_sessionKey);
    if (raw == null) return null;
    try {
      final json = jsonDecode(raw) as Map<String, dynamic>;
      final session = SavedNasSession(
        json['url'] as String, json['username'] as String,
        json['token'] as String, DateTime.parse(json['expires'] as String).toUtc(),
      );
      return session.expired ? null : session;
    } catch (_) {
      return null;
    }
  }

  Future<SavedNasSession> login(String address, String username, String password) async {
    final api = NasApiClient(address);
    try {
      await api.checkConnection();
      final name = await api.login(username, password);
      final expires = api.tokenExpiresAt;
      if (expires == null || api.token == null || !expires.isAfter(DateTime.now().toUtc())) {
        throw const NasApiException('NAS hat keine gültige Sitzungsdauer zurückgemeldet.');
      }
      final session = SavedNasSession(address.trim(), name, api.token!, expires.toUtc());
      final prefs = await SharedPreferences.getInstance();
      final owner = '${session.address}|${session.username}';
      final oldOwner = prefs.getString(_baselineOwnerKey);
      if (oldOwner != null && oldOwner != owner) {
        // Never reuse sync history for a different account or NAS.
        await prefs.remove(_baselineKey);
      }
      await prefs.setString(_baselineOwnerKey, owner);
      await prefs.setString(_sessionKey, jsonEncode({
        'url': session.address, 'username': session.username, 'token': session.token,
        'expires': session.expiresAt.toIso8601String(),
      }));
      await prefs.setString(_legacyAddressKey, session.address);
      return session;
    } finally {
      api.close();
    }
  }

  /// A restored backup is not proof that the NAS should be overwritten.
  /// Force a fresh comparison before accepting edits to existing IDs.
  Future<void> resetBaselineForRestoredBackup() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_baselineKey);
  }

  Future<void> logout() async {
    final session = await savedSession();
    final prefs = await SharedPreferences.getInstance();
    // Immediately forget local session, even when NAS is offline.
    await prefs.remove(_sessionKey);
    // Keep baseline: after next login we must still recognize older changes.
    if (session == null) return;
    final api = NasApiClient(session.address)..restoreToken(session.token);
    try { await api.logout(); } catch (_) {} finally { api.close(); }
  }

  Future<Map<String, _Baseline>> _readBaseline() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_baselineKey);
    if (raw == null) return <String, _Baseline>{};
    try {
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      return decoded.map((key, value) => MapEntry(key, _Baseline.fromJson(value)));
    } catch (_) {
      throw const NasApiException('Lokaler Synchronisationsstand beschädigt. Keine automatische Übertragung; zuerst JSON-Backup erstellen.');
    }
  }

  Future<void> _saveBaseline(Map<String, _Baseline> base) async {
    final prefs = await SharedPreferences.getInstance();
    final ok = await prefs.setString(_baselineKey,
        jsonEncode(base.map((key, value) => MapEntry(key, value.toJson()))));
    if (!ok) throw const NasApiException('Synchronisationsstand konnte nicht gespeichert werden.');
  }

  Future<NasApiClient> _client() async {
    final session = await savedSession();
    if (session == null) {
      throw const NasApiException('Keine aktive Anmeldung. Bitte in den NAS-Einstellungen anmelden.');
    }
    return NasApiClient(session.address)..restoreToken(session.token);
  }

  Future<NasSyncReport> synchronize() {
    if (_inFlight != null) return _inFlight!;
    final pending = _synchronize();
    _inFlight = pending;
    pending.then((_) { _inFlight = null; }, onError: (Object _) { _inFlight = null; });
    return pending;
  }

  Future<NasSyncReport> _synchronize() async {
    final api = await _client();
    try {
      final current = await _store.load();
      final currentById = {for (final r in current) r.id: r};
      final base = await _readBaseline();
      final remote = await api.getRecipes();
      if (remote.length >= 500) {
        throw const NasApiException('Die NAS-Liste hat 500 Rezepte erreicht. Kein automatischer Abgleich möglich.');
      }
      final remoteById = {for (final r in remote) r.id: r};
      final merged = List<Recipe>.from(current);
      final conflicts = <NasSyncConflict>[];
      var uploaded = 0;
      var downloaded = 0;
      var updated = 0;
      var identical = 0;
      var pendingDeletions = 0;

      // The server might have changed since the last run. The baseline describes
      // the last verified server state, and protects independently edited data.
      for (final local in current) {
        final server = remoteById[local.id];
        final previous = base[local.id];
        final decision = decideSync(local: local, remote: server,
            lastSynced: previous?.recipe, lastRevision: previous?.revision);
        if (server == null) {
          if (decision == SyncDecision.deletedRemotely) {
            conflicts.add(NasSyncConflict(id: local.id, title: local.title,
              local: local, differences: const ['Rezept auf NAS nicht mehr vorhanden. Nicht erneut hochgeladen.']));
            continue;
          }
          final created = await api.createRecipe(local);
          base[local.id] = _Baseline(recipe: created, revision: created.revision);
          uploaded++;
          await _saveBaseline(base);
          continue;
        }
        final differences = recipeDifferences(local, server);
        if (decision == SyncDecision.identical) {
          identical++;
          base[local.id] = _Baseline(recipe: server, revision: server.revision);
          continue;
        }
        if (decision == SyncDecision.updateNas) {
          final saved = await api.updateRecipe(local, previous!.revision);
          base[local.id] = _Baseline(recipe: saved, revision: saved.revision);
          updated++;
          await _saveBaseline(base);
        } else if (decision == SyncDecision.updateLocal) {
          final index = merged.indexWhere((r) => r.id == local.id);
          if (index != -1) merged[index] = server;
          base[local.id] = _Baseline(recipe: server, revision: server.revision);
          downloaded++;
        } else {
          conflicts.add(NasSyncConflict(id: local.id, title: local.title,
            local: local, remote: server, differences: differences));
        }
      }

      for (final server in remote) {
        if (currentById.containsKey(server.id)) continue;
        if (base.containsKey(server.id)) {
          // Local removal is intentional; do not silently restore deleted rows.
          pendingDeletions++;
          conflicts.add(NasSyncConflict(id: server.id, title: server.title, remote: server,
            differences: const ['Lokal gelöscht; auf der NAS noch vorhanden. Es erfolgt keine automatische Löschung.']));
          continue;
        }
        merged.add(server);
        base[server.id] = _Baseline(recipe: server, revision: server.revision);
        downloaded++;
      }

      // Do not silently clobber a recipe edited while a network request ran.
      final latest = await _store.load();
      final originalMap = {for (final recipe in current) recipe.id: recipe};
      final latestMap = {for (final recipe in latest) recipe.id: recipe};
      final safe = List<Recipe>.from(latest);
      var localChangedOnWire = false;
      for (final proposal in merged) {
        final before = originalMap[proposal.id];
        final now = latestMap[proposal.id];
        if (before != null && now == null) {
          localChangedOnWire = true;
          continue;
        }
        if (before == null && now != null && recipeDifferences(now, proposal).isNotEmpty) {
          localChangedOnWire = true;
          base.remove(proposal.id);
          continue;
        }
        if (before != null && now != null && recipeDifferences(now, before).isNotEmpty) {
          localChangedOnWire = true;
          continue;
        }
        if (now == null && before == null) {
          safe.add(proposal);
        } else if (now != null && recipeDifferences(now, proposal).isNotEmpty) {
          final index = safe.indexWhere((e) => e.id == proposal.id);
          if (index != -1) safe[index] = proposal;
        }
      }
      if (localChangedOnWire) {
        // Avoid committing a stale baseline for recipes changed while syncing.
        for (final entry in latestMap.entries) {
          final old = originalMap[entry.key];
          if (old != null && recipeDifferences(old, entry.value).isNotEmpty) base.remove(entry.key);
        }
      }
      await _store.save(safe);
      await _saveBaseline(base);
      return NasSyncReport(uploaded: uploaded, downloaded: downloaded,
          updated: updated, identical: identical,
          pendingDeletions: pendingDeletions, conflicts: conflicts);
    } finally {
      api.close();
    }
  }

  /// Explicit conflict decision. Never ignore server revision changes.
  Future<void> resolveConflict(NasSyncConflict conflict, {required bool keepLocal}) async {
    if (!conflict.canChoose) {
      throw const NasApiException('Gelöschte Rezepte werden in dieser Version nicht automatisch überschrieben.');
    }
    // Wait for an in-flight automatic sync to avoid concurrent writes.
    final underway = _inFlight;
    if (underway != null) await underway;
    final api = await _client();
    try {
      final recipes = await _store.load();
      final localIndex = recipes.indexWhere((e) => e.id == conflict.id);
      if (localIndex == -1 || recipeDifferences(recipes[localIndex], conflict.local!).isNotEmpty) {
        throw const NasApiException('Das lokale Rezept wurde inzwischen geändert. Bitte erneut vergleichen.');
      }
      final remoteList = await api.getRecipes();
      final match = remoteList.where((e) => e.id == conflict.id);
      if (match.isEmpty || match.first.revision != conflict.remote!.revision ||
          recipeDifferences(match.first, conflict.remote!).isNotEmpty) {
        throw const NasApiException('Das NAS-Rezept hat sich inzwischen geändert. Bitte erneut vergleichen.');
      }
      final base = await _readBaseline();
      if (keepLocal) {
        final result = await api.updateRecipe(conflict.local!, match.first.revision);
        base[conflict.id] = _Baseline(recipe: result, revision: result.revision);
      } else {
        final changed = List<Recipe>.from(recipes);
        changed[localIndex] = match.first;
        await _store.save(changed);
        base[conflict.id] = _Baseline(recipe: match.first, revision: match.first.revision);
      }
      await _saveBaseline(base);
    } finally {
      api.close();
    }
  }
}
