import 'recipe.dart';
import 'sync_plan.dart';

enum SyncDecision {
  identical,
  uploadNew,
  downloadNew,
  updateNas,
  updateLocal,
  conflict,
  deletedLocally,
  deletedRemotely,
}

/// Conservative three-way recipe comparison using a last-confirmed snapshot.
/// Revision is checked again on every write by the backend's If-Match header.
SyncDecision decideSync({
  required Recipe? local,
  required Recipe? remote,
  required Recipe? lastSynced,
  required int? lastRevision,
}) {
  if (local == null && remote == null) return SyncDecision.identical;
  if (local == null) {
    return lastSynced == null ? SyncDecision.downloadNew : SyncDecision.deletedLocally;
  }
  if (remote == null) {
    return lastSynced == null ? SyncDecision.uploadNew : SyncDecision.deletedRemotely;
  }
  if (recipeDifferences(local, remote).isEmpty) return SyncDecision.identical;
  if (lastSynced == null || lastRevision == null || lastRevision < 1) {
    return SyncDecision.conflict;
  }
  final changedHere = recipeDifferences(local, lastSynced).isNotEmpty;
  final changedNas = recipeDifferences(remote, lastSynced).isNotEmpty;
  if (changedHere && !changedNas && remote.revision == lastRevision) {
    return SyncDecision.updateNas;
  }
  if (!changedHere && changedNas) return SyncDecision.updateLocal;
  return SyncDecision.conflict;
}
