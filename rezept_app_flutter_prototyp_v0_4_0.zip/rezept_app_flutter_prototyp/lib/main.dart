import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'backup.dart';

import 'recipe.dart';
import 'recipe_store.dart';
import 'nas_sync_page.dart';
import 'nas_sync_engine.dart';
import 'household_page.dart';
import 'sync_plan.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const RezeptApp());
}

class RezeptApp extends StatelessWidget {
  const RezeptApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Meine Rezepte',
        debugShowCheckedModeBanner: false,
        themeMode: ThemeMode.system,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF356F65)),
          useMaterial3: true,
          inputDecorationTheme: const InputDecorationTheme(
            border: OutlineInputBorder(),
            contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 13),
          ),
        ),
        darkTheme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF75AA9B),
            brightness: Brightness.dark,
          ),
          useMaterial3: true,
          inputDecorationTheme: const InputDecorationTheme(
            border: OutlineInputBorder(),
            contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 13),
          ),
        ),
        home: const RecipeHomePage(),
      );
}

class RecipeHomePage extends StatefulWidget {
  const RecipeHomePage({super.key});

  @override
  State<RecipeHomePage> createState() => _RecipeHomePageState();
}

class _RecipeHomePageState extends State<RecipeHomePage> with WidgetsBindingObserver {
  final NasSyncEngine _nas = NasSyncEngine();
  bool _syncing = false;
  bool _syncAgain = false;
  String? _lastSyncError;

  final RecipeStore _store = RecipeStore();
  final TextEditingController _searchController = TextEditingController();
  List<Recipe>? _recipes;
  String? _error;
  String _query = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load().then((_) => _autoSync());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _searchController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _autoSync();
  }

  Future<void> _autoSync() async {
    if (_syncing) { _syncAgain = true; return; }
    if (await _nas.savedSession() == null || !mounted) return;
    setState(() { _syncing = true; _lastSyncError = null; });
    try {
      await _nas.synchronize();
      await _load();
    } catch (e) {
      if (mounted) setState(() => _lastSyncError = '$e');
    } finally {
      if (mounted) setState(() => _syncing = false);
      if (_syncAgain) {
        _syncAgain = false;
        if (mounted) unawaited(_autoSync());
      }
    }
  }

  Future<void> _load() async {
    try {
      final recipes = await _store.load();
      if (mounted) setState(() { _recipes = recipes; _error = null; });
    } catch (e) {
      if (mounted) setState(() { _error = '$e'; });
    }
  }

  Future<void> _upsert(Recipe recipe) async {
    final updated = List<Recipe>.from(_recipes ?? []);
    final index = updated.indexWhere((e) => e.id == recipe.id);
    if (index == -1) {
      updated.add(recipe);
    } else {
      updated[index] = recipe;
    }
    await _store.save(updated);
    if (mounted) setState(() => _recipes = updated);
    unawaited(_autoSync());
  }

  Future<void> _upsertEdited(Recipe edited, Recipe originallyOpened) async {
    final latest = (_recipes ?? []).where((e) => e.id == edited.id);
    if (latest.isEmpty ||
        recipeDifferences(latest.first, originallyOpened).isNotEmpty) {
      throw StateError('Dieses Rezept wurde inzwischen auf diesem Gerät geändert. '
          'Bitte die Rezeptansicht erneut öffnen und die Änderungen prüfen.');
    }
    await _upsert(edited);
  }

  Future<void> _remove(String id) async {
    final updated = List<Recipe>.from(_recipes ?? [])..removeWhere((e) => e.id == id);
    await _store.save(updated);
    if (mounted) setState(() => _recipes = updated);
    unawaited(_autoSync());
  }

  Future<void> _openNasSync() async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute(builder: (_) => NasSyncPage(
        engine: _nas, onDataChanged: _load,
      )),
    );
    if (mounted) await _load();
  }

  void _showMessage(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _exportBackup() async {
    final recipes = _recipes;
    if (recipes == null) return;
    try {
      await exportRecipeBackup(recipes);
      _showMessage('Backup wurde zum Herunterladen bereitgestellt. Bitte Datei aufbewahren.');
    } catch (e) {
      _showMessage('Export fehlgeschlagen: $e');
    }
  }

  Future<void> _importBackup() async {
    try {
      // The picker must be opened directly from the user's menu action.
      final backup = await selectRecipeBackup();
      if (backup == null || !mounted) return;

      final shouldRestore = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Backup wiederherstellen?'),
          content: Text(
            'Die Datei enthält ${backup.length} '
            '${backup.length == 1 ? 'Rezept' : 'Rezepte'}. '
            'Beim Wiederherstellen werden ALLE derzeit lokal gespeicherten '
            'Rezepte (${_recipes?.length ?? 0}) ersetzt. '
            'Erstelle vorher ein Backup deiner aktuellen Rezepte, falls du sie behalten möchtest.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Abbrechen'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Ersetzen'),
            ),
          ],
        ),
      );
      if (shouldRestore != true || !mounted) return;
      await _store.save(backup);
      await _nas.resetBaselineForRestoredBackup();
      if (!mounted) return;
      _searchController.clear();
      setState(() {
        _recipes = backup;
        _query = '';
      });
      _showMessage('${backup.length} Rezepte wiederhergestellt.');
    } catch (e) {
      _showMessage('Import fehlgeschlagen: $e');
    }
  }

  void _showError(Object error) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Speichern fehlgeschlagen: $error')),
    );
  }

  Future<void> _add() async {
    final created = await Navigator.of(context).push<Recipe>(
      MaterialPageRoute(builder: (_) => const RecipeEditorPage()),
    );
    if (created == null) return;
    try {
      await _upsert(created);
    } catch (e) {
      _showError(e);
    }
  }

  Future<void> _open(Recipe recipe) async {
    // Update the edit baseline after each successful save, including repeated
    // edits while the same detail page is open.
    var lastSeen = recipe;
    await Navigator.of(context).push<void>(
      MaterialPageRoute(
        builder: (_) => RecipeDetailPage(
          recipe: recipe,
          onSave: (edited) async {
            await _upsertEdited(edited, lastSeen);
            lastSeen = edited;
          },
          onDelete: _remove,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final matching = (_recipes ?? [])
        .where((r) => r.title.toLowerCase().contains(_query.toLowerCase()))
        .toList()
      ..sort((a, b) => a.title.compareTo(b.title));
    return Scaffold(
      appBar: AppBar(
        title: const Text('Meine Rezepte'),
        actions: [
          if (_syncing) const Center(child: SizedBox(width: 18, height: 18,
              child: CircularProgressIndicator(strokeWidth: 2))),
          if (_lastSyncError != null)
            IconButton(tooltip: 'NAS momentan nicht erreichbar – Rezepte bleiben lokal',
              icon: const Icon(Icons.cloud_off_outlined),
              onPressed: () => _showMessage('NAS-Abgleich ausstehend. Öffne die Synchronisierung.')),
          IconButton(
            tooltip: 'Wochenplan, Einkaufen und Vorrat',
            icon: const Icon(Icons.calendar_month_outlined),
            onPressed: _recipes == null ? null : () async {
              await Navigator.of(context).push<void>(
                MaterialPageRoute(builder: (_) => const HouseholdPage()),
              );
            },
          ),
          IconButton(
            tooltip: 'Synology-Abgleich',
            onPressed: _recipes == null ? null : _openNasSync,
            icon: const Icon(Icons.cloud_sync_outlined),
          ),
          PopupMenuButton<String>(
            tooltip: 'Datensicherung',
            icon: const Icon(Icons.backup_outlined),
            enabled: _recipes != null,
            onSelected: (action) {
              if (action == 'export') {
                _exportBackup();
              } else if (action == 'import') {
                _importBackup();
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(
                value: 'export',
                child: ListTile(
                  leading: Icon(Icons.download_outlined),
                  title: Text('Backup exportieren'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              PopupMenuItem(
                value: 'import',
                child: ListTile(
                  leading: Icon(Icons.upload_file_outlined),
                  title: Text('Backup importieren'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
            ],
          ),
        ],
      ),
      floatingActionButton: _recipes == null
          ? null
          : FloatingActionButton.extended(
              onPressed: _add,
              icon: const Icon(Icons.add),
              label: const Text('Rezept hinzufügen'),
            ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 850),
          child: _error != null
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('Rezepte konnten nicht geladen werden.'),
                      const SizedBox(height: 12),
                      SelectableText(_error!),
                      const SizedBox(height: 12),
                      FilledButton(onPressed: _load, child: const Text('Erneut versuchen')),
                    ],
                  ),
                )
              : _recipes == null
                  ? const Center(child: CircularProgressIndicator())
                  : ListView(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
                      children: [
                        Card(
                          child: ListTile(
                            leading: const Icon(Icons.calendar_month_outlined),
                            title: const Text('Wochenplan, Einkauf & Vorrat'),
                            subtitle: const Text('Wochenmenü planen, einkaufen und gekocht abhaken'),
                            trailing: const Icon(Icons.chevron_right),
                            onTap: () => Navigator.of(context).push<void>(
                              MaterialPageRoute(builder: (_) => const HouseholdPage()),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text('Rezeptbuch', style: Theme.of(context).textTheme.headlineMedium),
                        const SizedBox(height: 4),
                        const Text('Rezepte manuell verwalten – ohne KI-Import.'),
                        const SizedBox(height: 18),
                        TextField(
                          controller: _searchController,
                          decoration: const InputDecoration(
                            labelText: 'Rezept suchen',
                            prefixIcon: Icon(Icons.search),
                          ),
                          onChanged: (value) => setState(() => _query = value),
                        ),
                        const SizedBox(height: 16),
                        if (matching.isEmpty)
                          Padding(
                            padding: const EdgeInsets.all(20),
                            child: Text(_recipes!.isEmpty
                                ? 'Noch keine Rezepte vorhanden. Tippe auf „Rezept hinzufügen“.'
                                : 'Kein Rezept für diese Suche gefunden.'),
                          ),
                        ...matching.map((recipe) => Card(
                              child: ListTile(
                                leading: const CircleAvatar(child: Icon(Icons.restaurant_menu)),
                                title: Text(recipe.title),
                                subtitle: Text(
                                  '${recipe.category} · ${recipe.basePortions} '
                                  '${recipe.basePortions == 1 ? 'Portion' : 'Portionen'}'
                                  '${recipe.caloriesPerPortion != null ? ' · ${recipe.caloriesPerPortion} kcal/Portion' : ''}',
                                ),
                                trailing: const Icon(Icons.chevron_right),
                                onTap: () => _open(recipe),
                              ),
                            )),
                        const SizedBox(height: 12),
                        const Text(
                          'Rezepte bleiben lokal verfügbar. '
                          'Neue und bearbeitete Rezepte werden bei erreichbarer NAS automatisch abgeglichen. '
                          'Konflikte und Löschungen müssen manuell geprüft werden. '
                          'Nutze weiterhin den JSON-Backup-Export.',
                          style: TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
        ),
      ),
    );
  }
}

class RecipeDetailPage extends StatefulWidget {
  const RecipeDetailPage({
    super.key,
    required this.recipe,
    required this.onSave,
    required this.onDelete,
  });

  final Recipe recipe;
  final Future<void> Function(Recipe) onSave;
  final Future<void> Function(String) onDelete;

  @override
  State<RecipeDetailPage> createState() => _RecipeDetailPageState();
}

class _RecipeDetailPageState extends State<RecipeDetailPage> {
  late Recipe _recipe;
  late int _portions;

  @override
  void initState() {
    super.initState();
    _recipe = widget.recipe;
    _portions = _recipe.basePortions;
  }

  Future<void> _edit() async {
    final edited = await Navigator.of(context).push<Recipe>(
      MaterialPageRoute(builder: (_) => RecipeEditorPage(initial: _recipe)),
    );
    if (edited == null) return;
    try {
      await widget.onSave(edited);
      if (mounted) setState(() {
        _recipe = edited;
        _portions = edited.basePortions;
      });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  Future<void> _delete() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Rezept löschen?'),
        content: Text('„${_recipe.title}“ wird nur aus der lokalen Rezeptsammlung gelöscht.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Abbrechen')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Löschen')),
        ],
      ),
    );
    if (confirmed != true) return;
    try {
      await widget.onDelete(_recipe.id);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final factor = _portions / _recipe.basePortions;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rezept'),
        actions: [
          IconButton(tooltip: 'Bearbeiten', onPressed: _edit, icon: const Icon(Icons.edit_outlined)),
          IconButton(tooltip: 'Löschen', onPressed: _delete, icon: const Icon(Icons.delete_outline)),
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 850),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text(_recipe.title, style: Theme.of(context).textTheme.headlineMedium),
              Text(_recipe.category),
              const SizedBox(height: 20),
              Card.filled(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      const Expanded(child: Text('Portionen', style: TextStyle(fontWeight: FontWeight.bold))),
                      IconButton.filledTonal(
                        tooltip: 'Weniger Portionen',
                        onPressed: _portions > 1 ? () => setState(() => _portions--) : null,
                        icon: const Icon(Icons.remove),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 18),
                        child: Text('$_portions', style: Theme.of(context).textTheme.headlineSmall),
                      ),
                      IconButton.filledTonal(
                        tooltip: 'Mehr Portionen',
                        onPressed: _portions < 50 ? () => setState(() => _portions++) : null,
                        icon: const Icon(Icons.add),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Wrap(spacing: 8, runSpacing: 8, children: [
                if (_recipe.itemsPerPortion != null)
                  Chip(label: Text('${_recipe.itemsPerPortion! * _portions} ${_recipe.itemName}')),
                if (_recipe.caloriesPerPortion != null)
                  Chip(label: Text('${_recipe.caloriesPerPortion! * _portions} kcal gesamt')),
                if (_recipe.timeMinutes != null)
                  Chip(label: Text('${_recipe.timeMinutes} Min.')),
                if (_recipe.mealPrep) const Chip(label: Text('Meal Prep')),
                if (_recipe.freezable) const Chip(label: Text('Einfrierbar')),
              ]),
              const SizedBox(height: 24),
              Text('Zutaten', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              ..._recipe.ingredients.map((ingredient) => Card(
                    child: ListTile(
                      title: Text(ingredient.foodName),
                      subtitle: ingredient.productName.isNotEmpty
                          ? Text(ingredient.productName)
                          : null,
                      trailing: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text('${formatAmount(ingredient.amount * factor)} ${ingredient.unit}',
                              style: const TextStyle(fontWeight: FontWeight.bold)),
                          if (ingredient.pieces != null)
                            Text('${formatAmount(ingredient.pieces! * factor)} ${ingredient.pieceUnit}',
                                style: Theme.of(context).textTheme.bodySmall),
                        ],
                      ),
                    ),
                  )),
              const SizedBox(height: 22),
              Text('Zubereitung', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              Text(_recipe.preparation.trim().isEmpty
                  ? 'Noch keine Zubereitung hinterlegt. Über „Bearbeiten“ ergänzen.'
                  : _recipe.preparation),
              const SizedBox(height: 24),
              const Card.outlined(
                child: Padding(
                  padding: EdgeInsets.all(14),
                  child: Text('Rezeptansicht und Portionsrechnung sind aktiv. '
                      'Zutaten aus dem Vorrat abbuchen und „gekocht“ markieren '
                      'folgen erst mit dem Vorratsmodul.'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class IngredientDraft {
  IngredientDraft.fromLine(IngredientLine? line)
      : food = TextEditingController(text: line?.foodName ?? ''),
        product = TextEditingController(text: line?.productName ?? ''),
        amount = TextEditingController(text: line == null ? '' : formatAmount(line.amount)),
        unit = line?.unit ?? 'g',
        pieces = TextEditingController(text: line?.pieces == null ? '' : formatAmount(line!.pieces!)),
        pieceUnit = TextEditingController(text: line?.pieceUnit ?? '');

  final TextEditingController food;
  final TextEditingController product;
  final TextEditingController amount;
  String unit;
  final TextEditingController pieces;
  final TextEditingController pieceUnit;

  IngredientLine toLine() => IngredientLine(
        foodName: food.text.trim(),
        productName: product.text.trim(),
        amount: parsePositiveNumber(amount.text)!,
        unit: unit,
        pieces: pieces.text.trim().isEmpty ? null : parsePositiveNumber(pieces.text),
        pieceUnit: pieceUnit.text.trim(),
      );

  void dispose() {
    food.dispose();
    product.dispose();
    amount.dispose();
    pieces.dispose();
    pieceUnit.dispose();
  }
}

double? parsePositiveNumber(String text) {
  final parsed = double.tryParse(text.trim().replaceAll(',', '.'));
  return parsed != null && parsed.isFinite && parsed > 0 ? parsed : null;
}

class RecipeEditorPage extends StatefulWidget {
  const RecipeEditorPage({super.key, this.initial});
  final Recipe? initial;

  @override
  State<RecipeEditorPage> createState() => _RecipeEditorPageState();
}

class _RecipeEditorPageState extends State<RecipeEditorPage> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _title;
  late final TextEditingController _portions;
  late final TextEditingController _calories;
  late final TextEditingController _time;
  late final TextEditingController _itemCount;
  late final TextEditingController _itemName;
  late final TextEditingController _preparation;
  late String _category;
  late bool _freezable;
  late bool _mealPrep;
  late List<IngredientDraft> _ingredients;
  bool _saving = false;

  static const _categories = <String>[
    'Frühstück', 'Mittagessen', 'Abendessen', 'Snack', 'Sonstiges'
  ];

  @override
  void initState() {
    super.initState();
    final r = widget.initial;
    _title = TextEditingController(text: r?.title ?? '');
    _portions = TextEditingController(text: r?.basePortions.toString() ?? '1');
    _calories = TextEditingController(text: r?.caloriesPerPortion?.toString() ?? '');
    _time = TextEditingController(text: r?.timeMinutes?.toString() ?? '');
    _itemCount = TextEditingController(text: r?.itemsPerPortion?.toString() ?? '');
    _itemName = TextEditingController(text: r?.itemName ?? 'Stück');
    _preparation = TextEditingController(text: r?.preparation ?? '');
    _category = _categories.contains(r?.category) ? r!.category : 'Sonstiges';
    _freezable = r?.freezable ?? false;
    _mealPrep = r?.mealPrep ?? false;
    _ingredients = r == null
        ? [IngredientDraft.fromLine(null)]
        : r.ingredients.map((e) => IngredientDraft.fromLine(e)).toList();
  }

  @override
  void dispose() {
    _title.dispose();
    _portions.dispose();
    _calories.dispose();
    _time.dispose();
    _itemCount.dispose();
    _itemName.dispose();
    _preparation.dispose();
    for (final ingredient in _ingredients) {
      ingredient.dispose();
    }
    super.dispose();
  }

  String? _required(String? v) => v == null || v.trim().isEmpty ? 'Pflichtfeld' : null;
  String? _positiveInteger(String? v, {bool required = false}) {
    if ((v ?? '').trim().isEmpty) return required ? 'Pflichtfeld' : null;
    final n = int.tryParse(v!.trim());
    return n == null || n <= 0 ? 'Ganze Zahl größer als 0 eingeben' : null;
  }

  void _removeIngredient(IngredientDraft draft) {
    setState(() => _ingredients.remove(draft));
    WidgetsBinding.instance.addPostFrameCallback((_) => draft.dispose());
  }

  void _save() {
    if (_saving || !_formKey.currentState!.validate()) return;
    if (_ingredients.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bitte mindestens eine Zutat hinzufügen.')),
      );
      return;
    }
    setState(() => _saving = true);
    final recipe = Recipe(
      id: widget.initial?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      title: _title.text.trim(),
      category: _category,
      basePortions: int.parse(_portions.text.trim()),
      caloriesPerPortion: _calories.text.trim().isEmpty ? null : int.parse(_calories.text.trim()),
      timeMinutes: _time.text.trim().isEmpty ? null : int.parse(_time.text.trim()),
      itemsPerPortion: _itemCount.text.trim().isEmpty ? null : int.parse(_itemCount.text.trim()),
      itemName: _itemName.text.trim().isEmpty ? 'Stück' : _itemName.text.trim(),
      ingredients: _ingredients.map((e) => e.toLine()).toList(),
      preparation: _preparation.text.trim(),
      freezable: _freezable,
      mealPrep: _mealPrep,
    );
    Navigator.of(context).pop(recipe);
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 760;
    return Scaffold(
      appBar: AppBar(title: Text(widget.initial == null ? 'Neues Rezept' : 'Rezept bearbeiten')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 960),
          child: Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
              children: [
                Text('Grunddaten', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _title,
                  decoration: const InputDecoration(labelText: 'Rezeptname *'),
                  validator: _required,
                  textCapitalization: TextCapitalization.sentences,
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: _category,
                  decoration: const InputDecoration(labelText: 'Mahlzeitenkategorie'),
                  items: _categories.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                  onChanged: (v) { if (v != null) setState(() => _category = v); },
                ),
                const SizedBox(height: 12),
                if (wide)
                  Row(children: [
                    Expanded(child: _portionInput()),
                    const SizedBox(width: 12),
                    Expanded(child: _calorieInput()),
                    const SizedBox(width: 12),
                    Expanded(child: _timeInput()),
                  ])
                else ...[
                  _portionInput(),
                  const SizedBox(height: 12),
                  _calorieInput(),
                  const SizedBox(height: 12),
                  _timeInput(),
                ],
                const SizedBox(height: 12),
                if (wide)
                  Row(children: [
                    Expanded(child: _countInput()),
                    const SizedBox(width: 12),
                    Expanded(child: _itemNameInput()),
                  ])
                else ...[
                  _countInput(),
                  const SizedBox(height: 12),
                  _itemNameInput(),
                ],
                const SizedBox(height: 12),
                SwitchListTile(
                  title: const Text('Meal Prep geeignet'),
                  contentPadding: EdgeInsets.zero,
                  value: _mealPrep,
                  onChanged: (v) => setState(() => _mealPrep = v),
                ),
                SwitchListTile(
                  title: const Text('Einfrierbar'),
                  contentPadding: EdgeInsets.zero,
                  value: _freezable,
                  onChanged: (v) => setState(() => _freezable = v),
                ),
                const SizedBox(height: 20),
                Row(children: [
                  Expanded(child: Text('Zutaten', style: Theme.of(context).textTheme.titleLarge)),
                  OutlinedButton.icon(
                    onPressed: () => setState(() => _ingredients.add(IngredientDraft.fromLine(null))),
                    icon: const Icon(Icons.add),
                    label: const Text('Zutat'),
                  ),
                ]),
                const SizedBox(height: 6),
                const Text('Lebensmittel und konkretes Kaufprodukt werden getrennt erfasst.'),
                const SizedBox(height: 12),
                ..._ingredients.asMap().entries.map((entry) => Padding(
                      key: ObjectKey(entry.value),
                      padding: const EdgeInsets.only(bottom: 12),
                      child: _ingredientForm(entry.value, entry.key),
                    )),
                const SizedBox(height: 12),
                Text('Zubereitung', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _preparation,
                  decoration: const InputDecoration(
                    labelText: 'Zubereitungsschritte (optional)',
                    alignLabelWithHint: true,
                  ),
                  maxLines: 5,
                  textCapitalization: TextCapitalization.sentences,
                ),
                const SizedBox(height: 22),
                FilledButton.icon(
                  onPressed: _saving ? null : _save,
                  icon: const Icon(Icons.save_outlined),
                  label: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 14),
                    child: Text('Rezept speichern'),
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Prototyp: Speicherung lokal pro Gerät/Browser. '
                  'Ein Vorratsabzug erfolgt hier noch nicht.',
                  style: TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _portionInput() => TextFormField(
        controller: _portions,
        decoration: const InputDecoration(labelText: 'Grundportionen *'),
        keyboardType: TextInputType.number,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        validator: (v) => _positiveInteger(v, required: true),
      );

  Widget _calorieInput() => TextFormField(
        controller: _calories,
        decoration: const InputDecoration(labelText: 'kcal pro Portion (optional)'),
        keyboardType: TextInputType.number,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        validator: _positiveInteger,
      );

  Widget _timeInput() => TextFormField(
        controller: _time,
        decoration: const InputDecoration(labelText: 'Kochzeit in Min. (optional)'),
        keyboardType: TextInputType.number,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        validator: (v) {
          if ((v ?? '').trim().isEmpty) return null;
          return int.tryParse(v!) == null ? 'Zahl eingeben' : null;
        },
      );

  Widget _countInput() => TextFormField(
        controller: _itemCount,
        decoration: const InputDecoration(labelText: 'Fertige Stück je Portion (optional)'),
        keyboardType: TextInputType.number,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        validator: _positiveInteger,
      );

  Widget _itemNameInput() => TextFormField(
        controller: _itemName,
        decoration: const InputDecoration(labelText: 'Bezeichnung der fertigen Stücke'),
      );

  Widget _ingredientForm(IngredientDraft draft, int index) => Card.outlined(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(children: [
              Expanded(child: Text('Zutat ${index + 1}', style: const TextStyle(fontWeight: FontWeight.bold))),
              IconButton(
                tooltip: 'Zutat entfernen',
                onPressed: () => _removeIngredient(draft),
                icon: const Icon(Icons.delete_outline),
              ),
            ]),
            const SizedBox(height: 8),
            TextFormField(
              controller: draft.food,
              decoration: const InputDecoration(labelText: 'Lebensmittel *', hintText: 'z. B. Gouda'),
              validator: _required,
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: draft.product,
              decoration: const InputDecoration(labelText: 'Produkt / Marke (optional)', hintText: 'z. B. S-Budget'),
            ),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(
                flex: 2,
                child: TextFormField(
                  controller: draft.amount,
                  decoration: const InputDecoration(labelText: 'Menge *'),
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  validator: (v) => parsePositiveNumber(v ?? '') == null
                      ? 'Menge > 0 eingeben'
                      : null,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: draft.unit,
                  decoration: const InputDecoration(labelText: 'Einheit'),
                  items: const [
                    DropdownMenuItem(value: 'g', child: Text('g')),
                    DropdownMenuItem(value: 'ml', child: Text('ml')),
                    DropdownMenuItem(value: 'Stk.', child: Text('Stk.')),
                  ],
                  onChanged: (v) { if (v != null) setState(() => draft.unit = v); },
                ),
              ),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(
                child: TextFormField(
                  controller: draft.pieces,
                  decoration: const InputDecoration(labelText: 'Zusätzlich Stückzahl', hintText: '4'),
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  validator: (v) {
                    if ((v ?? '').trim().isEmpty) return null;
                    return parsePositiveNumber(v!) == null ? 'Zahl > 0' : null;
                  },
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextFormField(
                  controller: draft.pieceUnit,
                  decoration: const InputDecoration(labelText: 'Stück-Einheit', hintText: 'Scheiben'),
                  validator: (v) => draft.pieces.text.trim().isNotEmpty && (v ?? '').trim().isEmpty
                      ? 'Einheit fehlt'
                      : null,
                ),
              ),
            ]),
          ]),
        ),
      );
}
