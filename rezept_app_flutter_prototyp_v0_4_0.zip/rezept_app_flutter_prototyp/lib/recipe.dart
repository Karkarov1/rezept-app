import 'dart:convert';

/// Normalized ingredient name plus optional branded shopping product.
/// Quantities refer to [Recipe.basePortions], not one portion necessarily.
class IngredientLine {
  const IngredientLine({
    required this.foodName,
    required this.amount,
    required this.unit,
    this.productName = '',
    this.pieces,
    this.pieceUnit = '',
  });

  final String foodName;
  final String productName;
  final double amount;
  final String unit;
  final double? pieces;
  final String pieceUnit;

  Map<String, dynamic> toJson() => {
        'foodName': foodName,
        'productName': productName,
        'amount': amount,
        'unit': unit,
        'pieces': pieces,
        'pieceUnit': pieceUnit,
      };

  factory IngredientLine.fromJson(Map<String, dynamic> json) => IngredientLine(
        foodName: json['foodName'] as String? ?? '',
        productName: json['productName'] as String? ?? '',
        amount: (json['amount'] as num).toDouble(),
        unit: json['unit'] as String? ?? 'g',
        pieces: (json['pieces'] as num?)?.toDouble(),
        pieceUnit: json['pieceUnit'] as String? ?? '',
      );
}

class Recipe {
  const Recipe({
    required this.id,
    required this.title,
    required this.category,
    required this.basePortions,
    required this.ingredients,
    this.caloriesPerPortion,
    this.preparation = '',
    this.timeMinutes,
    this.itemsPerPortion,
    this.itemName = 'Stück',
    this.freezable = false,
    this.mealPrep = false,
    this.revision = 0,
  });

  final String id;
  final String title;
  final String category;
  final int basePortions;
  final List<IngredientLine> ingredients;
  final int? caloriesPerPortion;
  final int? timeMinutes;
  final int? itemsPerPortion;
  final String itemName;
  final String preparation;
  final bool freezable;
  final bool mealPrep;
  /// Version from NAS; 0 means unknown/local-only.
  final int revision;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'category': category,
        'basePortions': basePortions,
        'ingredients': ingredients.map((i) => i.toJson()).toList(),
        'caloriesPerPortion': caloriesPerPortion,
        'timeMinutes': timeMinutes,
        'itemsPerPortion': itemsPerPortion,
        'itemName': itemName,
        'preparation': preparation,
        'freezable': freezable,
        'mealPrep': mealPrep,
        'revision': revision,
      };

  factory Recipe.fromJson(Map<String, dynamic> json) => Recipe(
        id: json['id'] as String,
        title: json['title'] as String,
        category: json['category'] as String? ?? 'Sonstiges',
        basePortions: (json['basePortions'] as num).toInt(),
        ingredients: (json['ingredients'] as List<dynamic>? ?? [])
            .map((e) => IngredientLine.fromJson(e as Map<String, dynamic>))
            .toList(),
        caloriesPerPortion: (json['caloriesPerPortion'] as num?)?.toInt(),
        timeMinutes: (json['timeMinutes'] as num?)?.toInt(),
        itemsPerPortion: (json['itemsPerPortion'] as num?)?.toInt(),
        itemName: json['itemName'] as String? ?? 'Stück',
        preparation: json['preparation'] as String? ?? '',
        freezable: json['freezable'] as bool? ?? false,
        mealPrep: json['mealPrep'] as bool? ?? false,
        revision: (json['revision'] as num?)?.toInt() ?? 0,
      );

  double get totalBaseWeightGrams => ingredients
      .where((e) => e.unit == 'g')
      .fold<double>(0, (total, e) => total + e.amount);

  static const schinkenKaeseToast = Recipe(
    id: 'demo-schinken-kaese-toast',
    title: 'Schinken-Käse-Toast',
    category: 'Frühstück',
    basePortions: 1,
    itemsPerPortion: 2,
    itemName: 'Toasts',
    caloriesPerPortion: 722,
    ingredients: [
      IngredientLine(
        foodName: 'Toastbrot',
        productName: 'American Sandwich ohne Konservierungsstoffe · American',
        amount: 150,
        unit: 'g',
        pieces: 4,
        pieceUnit: 'Scheiben',
      ),
      IngredientLine(
        foodName: 'Gouda',
        productName: 'S-Budget',
        amount: 80,
        unit: 'g',
      ),
      IngredientLine(
        foodName: 'Toastschinken',
        productName: 'Tann',
        amount: 70,
        unit: 'g',
      ),
    ],
    // The screenshot does not provide preparation steps or a cooking time.
    preparation: '',
  );
}

String formatAmount(double value) {
  final s = value == value.roundToDouble()
      ? value.toInt().toString()
      : value.toStringAsFixed(2).replaceAll(RegExp(r'0+$'), '').replaceAll(RegExp(r'\.$'), '');
  return s.replaceAll('.', ',');
}

String encodeRecipes(List<Recipe> recipes) =>
    jsonEncode(recipes.map((recipe) => recipe.toJson()).toList());

List<Recipe> decodeRecipes(String jsonText) => (jsonDecode(jsonText) as List<dynamic>)
    .map((item) => Recipe.fromJson(item as Map<String, dynamic>))
    .toList();
