# Rezept-App – Flutter 0.3 (vorsichtiger NAS-Erstabgleich)

Version 0.3 behält die manuelle Rezeptverwaltung, den lokalen Speicher (gleichbleibender `shared_preferences`-Schlüssel) und den JSON-Backup-Export/-Import der Version 0.2 bei.

## Neu

- Synology-Abgleich über Wolkensymbol oben rechts.
- NAS-Adresse **am Gerät** eingeben und lokal speichern (nicht im öffentlichen Repository): `https://<NAS>.<TAILNET>.ts.net`.
- Anmeldung mit dem bereits eingerichteten **Backend 0.4** (ein persönliches Konto). Das Benutzerpasswort wird weder im Quellcode noch in `shared_preferences` gespeichert. Das zeitlich begrenzte Bearer-Token liegt nur im Arbeitsspeicher; beim App-Neustart erneut anmelden.
- Vorschau: nur lokal, nur auf NAS, identisch, gleiche ID mit unterschiedlichem Inhalt (Konflikt).
- Nur explizit bestätigt fehlende Rezepte kopieren; **nichts überschreiben und nichts löschen**. Der Backend-Endpunkt `/recipes` liefert max. 500 Rezepte – bei Erreichen des Limits wird der Abgleich vorsichtshalber verhindert.
- Rezepte bleiben auch ohne NAS lokal nutzbar.

## Anforderungen

- Bestehendes Synology Backend **0.4**, Datenbankschema inklusive Benutzeranmeldung und erstelltes Benutzerkonto.
- `Tailscale Serve` am NAS aktiv, HTTPS `/health/db` bereits vom Handy über Mobilfunk erreichbar.
- Auf jedem Gerät Tailscale verbunden, bevor synchronisiert wird.
- Im Backend `CORS_ORIGIN: "https://karkarov1.github.io"` (bereits Standard in Backend 0.4); erlaubt nur den GitHub-Pages-Ursprung. Bei Chrome kann eine Berechtigung für Netzwerkzugriff nötig sein.
- Flutter >= 3.24 und Web-Build in GitHub Actions. Für `package:http` ergänzt `pubspec.yaml` eine weitere Abhängigkeit.

## GitHub aktualisieren (bestehender Workflow)

1. Vorher **in der aktuellen App ein frisches JSON-Backup exportieren und extern aufbewahren**.
2. ZIP `rezept_app_flutter_prototyp_v0_3.zip` ins **Stammverzeichnis** des bereits vorhandenen GitHub-Repositorys `rezept-app` hochladen. ZIP *nicht* entpacken.
3. In `.github/workflows/deploy.yml` den bisherigen `unzip -q rezept_app_flutter_prototyp_v0_2.zip -d source` durch `unzip -q rezept_app_flutter_prototyp_v0_3.zip -d source` ersetzen. Alle anderen Zeilen beibehalten, einschließlich dem bisher erforderlichen `rm -f test/widget_test.dart`.
4. Commit → Actions: Build + Deploy grün abwarten.
5. Installierte PWA neu öffnen; bei Bedarf Webseite neu laden. Lokale Daten **nicht** löschen.
6. Wolkensymbol → NAS-HTTPS-URL eingeben → Benutzername/Passwort → anmelden → **Rezepte vergleichen** → Ergebnis prüfen → **Fehlende Rezepte übertragen**.

## Noch nicht enthalten

- Automatische Hintergrund-Synchronisierung
- Synchronisieren von nachträglichen Bearbeitungen und Löschungen
- Konfliktauflösung (gleiche ID, abweichender Inhalt wird **nicht** überschrieben)
- Offline-Änderungsprotokoll/Queue, geräteübergreifende Push-Updates
- Sicheres dauerhaftes Anmelde-Token (bei dieser Version bewusst nach jedem Neustart erneut anmelden)

**Sicherheit:** Niemals `DB_PASSWORD`, `API_TOKEN`, Benutzerpasswort oder ein Benutzer-Access-Token in GitHub committen. `Tailscale Funnel` bleibt deaktiviert; keine Ports am Router freigeben.

## Lokale Tests

```bash
flutter create --project-name rezept_app --platforms=web .
flutter pub get
rm -f test/widget_test.dart
flutter test
flutter build web --release --base-href /rezept-app/
```

Die neuen `test/sync_plan_test.dart` prüfen die vier Grundfälle: lokale, entfernte, identische und widersprüchliche Rezepte. Das ZIP wurde hier statisch geprüft; es wurde **nicht** mit einem Flutter-SDK kompiliert. Der GitHub-Actions-Build übernimmt die echte Kompilier- und Testprüfung.

## Version 0.3.1 – Vergleich nach der Übertragung (Bugfix)

- Gleichwertige Rezeptdaten werden mit den tatsächlichen PostgreSQL-Normalisierungen verglichen:
  Zutatenmenge/Stückzahl `numeric(12,3)`, `pcs`/`Stk.`, getrimmter Lebensmittelname.
- Alle anderen Felder bleiben streng verglichen. Abweichungen bei Zutatenreihenfolge,
  Mengen ab 0,001, Produktnamen, Zubereitung etc. bleiben echte Konflikte.
- Ein Konflikt zeigt im ausklappbaren Rezept die **abweichenden Felder** und deren
  Werte auf Handy/NAS an. Keine stille Konfliktauflösung.
- Die App lädt nach dem Hochladen den aktuellen NAS-Datenstand neu und erstellt
  daraus direkt eine neue Vergleichsanzeige. Nach einem Download ist auch ein
  weiterer Vergleich im gleichen Dialog auf dem aktualisierten lokalen Stand.
- Bestehende Datensätze werden weder automatisch überschrieben noch gelöscht.
  Der Export/Import der lokalen JSON-Backups bleibt bestehen.
- **Keine Backend-, Docker- oder NAS-Änderung nötig.** Die App benötigt weiterhin
  eine aktive Tailscale-Verbindung und eine gültige Anmeldung.
- Vor dem Update ein JSON-Backup in der bisherigen App erstellen; lokale
  Browser-/App-Daten nicht löschen. In Chrome kann bei einer veralteten PWA eine
  neue URL mit Versionsparameter den neuen Code laden.
- Es wurden zusätzliche Flutter-Unit-Tests aufgenommen; vor Freigabe `flutter test`
  und `flutter build web` in GitHub Actions ausführen. In der Erstellungsumgebung
  war kein Flutter SDK verfügbar.
