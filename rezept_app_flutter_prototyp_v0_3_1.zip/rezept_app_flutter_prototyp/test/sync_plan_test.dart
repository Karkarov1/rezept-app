import 'package:flutter_test/flutter_test.dart';
import 'package:rezept_app/recipe.dart';
import 'package:rezept_app/sync_plan.dart';

Recipe sample(String id, String title, {List<IngredientLine>? ingredients}) => Recipe(
      id: id,
      title: title,
      category: 'Mittagessen',
      basePortions: 2,
      ingredients: ingredients ??
          const [IngredientLine(foodName: 'Nudeln', amount: 200, unit: 'g')],
    );

void main() {
  test('New local recipe uploads without deletion', () {
    final plan = buildSyncPlan([sample('a', 'A')], []);
    expect(plan.toUpload.length, 1);
    expect(plan.toDownload, isEmpty);
    expect(plan.conflicts, isEmpty);
  });

  test('Remote-only recipe downloaded', () {
    final plan = buildSyncPlan([], [sample('b', 'B')]);
    expect(plan.toUpload, isEmpty);
    expect(plan.toDownload.single.id, 'b');
  });

  test('Same-ID different title is a field-specific conflict', () {
    final plan = buildSyncPlan([sample('a', 'local')], [sample('a', 'remote')]);
    expect(plan.toUpload, isEmpty);
    expect(plan.toDownload, isEmpty);
    expect(plan.conflicts.single.title, 'local');
    expect(plan.conflicts.single.differences.single, contains('Rezeptname'));
  });

  test('Identical recipes recognized', () {
    final plan = buildSyncPlan([sample('a', 'A')], [sample('a', 'A')]);
    expect(plan.unchanged, 1);
    expect(plan.conflicts, isEmpty);
  });

  test('Round-trip through PostgreSQL numeric(12,3) does not cause a conflict', () {
    final local = sample('a', 'Suppe', ingredients: [
      const IngredientLine(
        foodName: ' Mehl ', productName: 'Marke',
        amount: 1.23456, unit: 'Stk.', pieces: 4.00049, pieceUnit: 'Päckchen',
      ),
    ]);
    final remote = sample('a', 'Suppe', ingredients: [
      const IngredientLine(
        foodName: 'Mehl', productName: 'Marke',
        amount: 1.235, unit: 'pcs', pieces: 4.0, pieceUnit: 'Päckchen',
      ),
    ]);
    final plan = buildSyncPlan([local], [remote]);
    expect(plan.unchanged, 1);
    expect(plan.conflicts, isEmpty);
  });

  test('A real ingredient quantity difference remains a conflict', () {
    final plan = buildSyncPlan(
      [sample('a', 'A', ingredients: [
        const IngredientLine(foodName: 'Nudeln', amount: 200, unit: 'g'),
      ])],
      [sample('a', 'A', ingredients: [
        const IngredientLine(foodName: 'Nudeln', amount: 201, unit: 'g'),
      ])],
    );
    expect(plan.conflicts, hasLength(1));
    expect(plan.conflicts.single.differences.single, contains('Zutat 1 – Menge'));
    expect(plan.unchanged, 0);
  });

  test('Product differences and ingredient order are not ignored', () {
    final plan = buildSyncPlan(
      [sample('a', 'A', ingredients: [
        const IngredientLine(foodName: 'Salz', productName: 'A', amount: 2, unit: 'g'),
        const IngredientLine(foodName: 'Öl', amount: 50, unit: 'ml'),
      ])],
      [sample('a', 'A', ingredients: [
        const IngredientLine(foodName: 'Öl', amount: 50, unit: 'ml'),
        const IngredientLine(foodName: 'Salz', productName: 'B', amount: 2, unit: 'g'),
      ])],
    );
    expect(plan.conflicts, hasLength(1));
    expect(plan.conflicts.single.differences, isNotEmpty);
  });

  test('A changed preparation cannot be misclassified as identical', () {
    final local = sample('a', 'A');
    final remote = Recipe.fromJson({
      ...local.toJson(),
      'preparation': '10 Minuten kochen',
    });
    final plan = buildSyncPlan([local], [remote]);
    expect(plan.conflicts.single.differences.single, contains('Zubereitung'));
  });

  test('Re-reading uploaded server recipe yields a clean sync plan', () {
    final original = sample('a', 'Test', ingredients: [
      const IngredientLine(foodName: 'Milch', amount: 125.1234, unit: 'ml'),
    ]);
    final post = buildSyncPlan([original], []);
    expect(post.toUpload, hasLength(1));
    final stored = sample('a', 'Test', ingredients: [
      const IngredientLine(foodName: 'Milch', amount: 125.123, unit: 'ml'),
    ]);
    final verified = buildSyncPlan([original], [stored]);
    expect(verified.unchanged, 1);
    expect(verified.conflicts, isEmpty);
  });
}
