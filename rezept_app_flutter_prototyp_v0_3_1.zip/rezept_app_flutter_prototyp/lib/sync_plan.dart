import 'recipe.dart';

/// The server stores ingredient amounts/piece counts as NUMERIC(12,3).
/// Compare the effective stored value, not the floating-point JSON spelling.
/// PostgreSQL NUMERIC rounds positive halfway values away from zero.
int _storedThousandths(double value) => (value * 1000).round();

String _effectiveUnit(String unit) => unit == 'pcs' ? 'Stk.' : unit;

class RecipeConflict {
  const RecipeConflict({
    required this.recipeId,
    required this.title,
    required this.differences,
  });

  final String recipeId;
  final String title;
  /// Human-readable per-field differences; never silently overwrite these.
  final List<String> differences;
}

/// Conservative first-time sync: no update/delete of existing IDs.
class SyncPlan {
  const SyncPlan({
    required this.toUpload,
    required this.toDownload,
    required this.conflicts,
    required this.unchanged,
  });

  final List<Recipe> toUpload;
  final List<Recipe> toDownload;
  final List<RecipeConflict> conflicts;
  final int unchanged;
}

String _show(Object? value) {
  if (value == null) return '(leer)';
  if (value is bool) return value ? 'Ja' : 'Nein';
  if (value is String && value.isEmpty) return '(leer)';
  return value.toString();
}

/// Compares each field present in the current Flutter recipe model.
/// Only lossless server-side normalization is ignored (3 decimal numeric
/// precision, 'pcs' <-> 'Stk.', and trimmed ingredient food names).
/// In particular, do NOT ignore genuine text or ingredient-order changes.
List<String> recipeDifferences(Recipe local, Recipe remote) {
  final differences = <String>[];

  void check(String label, Object? a, Object? b) {
    if (a != b) {
      differences.add('$label: Gerät ${_show(a)} · NAS ${_show(b)}');
    }
  }

  check('Rezeptname', local.title, remote.title);
  check('Kategorie', local.category, remote.category);
  check('Grundportionen', local.basePortions, remote.basePortions);
  check('Kalorien pro Portion', local.caloriesPerPortion, remote.caloriesPerPortion);
  check('Zubereitungszeit (min)', local.timeMinutes, remote.timeMinutes);
  check('Stück pro Portion', local.itemsPerPortion, remote.itemsPerPortion);
  check('Stückbezeichnung', local.itemName, remote.itemName);
  check('Zubereitung', local.preparation, remote.preparation);
  check('Einfrierbar', local.freezable, remote.freezable);
  check('Meal-Prep', local.mealPrep, remote.mealPrep);
  check('Anzahl Zutaten', local.ingredients.length, remote.ingredients.length);

  final count = local.ingredients.length < remote.ingredients.length
      ? local.ingredients.length
      : remote.ingredients.length;
  for (var i = 0; i < count; i++) {
    final a = local.ingredients[i];
    final b = remote.ingredients[i];
    final label = 'Zutat ${i + 1}';
    // The backend trims only the normalized food name upon writing.
    check('$label – Lebensmittel', a.foodName.trim(), b.foodName.trim());
    check('$label – Kaufprodukt', a.productName, b.productName);
    if (_storedThousandths(a.amount) != _storedThousandths(b.amount)) {
      differences.add('$label – Menge: Gerät ${_show(a.amount)} · NAS ${_show(b.amount)}');
    }
    check('$label – Einheit', _effectiveUnit(a.unit), _effectiveUnit(b.unit));
    if (a.pieces == null || b.pieces == null) {
      check('$label – Stückzahl', a.pieces, b.pieces);
    } else if (_storedThousandths(a.pieces!) != _storedThousandths(b.pieces!)) {
      differences.add('$label – Stückzahl: Gerät ${_show(a.pieces)} · NAS ${_show(b.pieces)}');
    }
    check('$label – Stückeinheit', a.pieceUnit, b.pieceUnit);
  }
  return differences;
}

SyncPlan buildSyncPlan(List<Recipe> local, List<Recipe> remote) {
  final localById = {for (final recipe in local) recipe.id: recipe};
  final remoteById = {for (final recipe in remote) recipe.id: recipe};
  final toUpload = <Recipe>[];
  final toDownload = <Recipe>[];
  final conflicts = <RecipeConflict>[];
  var unchanged = 0;

  for (final recipe in local) {
    final onServer = remoteById[recipe.id];
    if (onServer == null) {
      toUpload.add(recipe);
    } else {
      final differences = recipeDifferences(recipe, onServer);
      if (differences.isEmpty) {
        unchanged++;
      } else {
        conflicts.add(RecipeConflict(
          recipeId: recipe.id,
          title: recipe.title,
          differences: differences,
        ));
      }
    }
  }
  for (final recipe in remote) {
    if (!localById.containsKey(recipe.id)) toDownload.add(recipe);
  }
  return SyncPlan(
    toUpload: toUpload,
    toDownload: toDownload,
    conflicts: conflicts,
    unchanged: unchanged,
  );
}
