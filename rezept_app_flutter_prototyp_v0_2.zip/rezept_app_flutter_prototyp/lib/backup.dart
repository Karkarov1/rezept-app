import 'dart:convert';
import 'dart:typed_data';

import 'package:file_saver/file_saver.dart';
import 'package:file_selector/file_selector.dart';

import 'recipe.dart';

/// Versioned, self-contained backup format for the user's recipe data.
/// A backup is independent of browser storage; it contains no login credentials.
String encodeRecipeBackup(List<Recipe> recipes, {DateTime? exportedAt}) {
  final timestamp = (exportedAt ?? DateTime.now()).toUtc().toIso8601String();
  return const JsonEncoder.withIndent('  ').convert({
    'format': 'rezept-app-backup',
    'schemaVersion': 1,
    'exportedAt': timestamp,
    'recipes': recipes.map((recipe) => recipe.toJson()).toList(),
  });
}

/// Strictly validate before replacing any stored data.
List<Recipe> decodeRecipeBackup(String jsonText) {
  try {
    final value = jsonDecode(jsonText);
    if (value is! Map<String, dynamic> ||
        value['format'] != 'rezept-app-backup' ||
        value['schemaVersion'] != 1 ||
        value['recipes'] is! List<dynamic>) {
      throw const FormatException('Kein unterstütztes Rezept-App-Backup (Version 1).');
    }

    final result = <Recipe>[];
    final ids = <String>{};
    for (final entry in value['recipes'] as List<dynamic>) {
      if (entry is! Map<String, dynamic>) {
        throw const FormatException('Ungültiger Rezepteintrag.');
      }
      final recipe = Recipe.fromJson(entry);
      if (recipe.id.trim().isEmpty ||
          recipe.title.trim().isEmpty ||
          recipe.basePortions <= 0 ||
          !ids.add(recipe.id)) {
        throw const FormatException('Ungültige oder doppelte Rezept-ID bzw. Portionszahl.');
      }
      for (final ingredient in recipe.ingredients) {
        if (ingredient.foodName.trim().isEmpty ||
            !ingredient.amount.isFinite ||
            ingredient.amount < 0 ||
            (ingredient.pieces != null &&
                (!ingredient.pieces!.isFinite || ingredient.pieces! < 0))) {
          throw const FormatException('Ungültige Zutat im Backup.');
        }
      }
      result.add(recipe);
    }
    return result;
  } on FormatException {
    rethrow;
  } catch (_) {
    throw const FormatException('Die Backup-Datei ist beschädigt oder ungültig.');
  }
}

Future<void> exportRecipeBackup(List<Recipe> recipes) async {
  final now = DateTime.now();
  final date = '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  await FileSaver.instance.saveFile(
    name: 'rezepte-backup-$date',
    bytes: Uint8List.fromList(utf8.encode(encodeRecipeBackup(recipes))),
    fileExtension: 'json',
    mimeType: MimeType.custom,
    customMimeType: 'application/json',
  );
}

/// Returns null when the user closes the file picker without selecting a file.
Future<List<Recipe>?> selectRecipeBackup() async {
  const jsonFiles = XTypeGroup(
    label: 'JSON Backup',
    extensions: <String>['json'],
    mimeTypes: <String>['application/json'],
    uniformTypeIdentifiers: <String>['public.json'],
  );
  final file = await openFile(acceptedTypeGroups: [jsonFiles]);
  if (file == null) return null;
  // Prevent accidental processing of arbitrarily large or invalid files.
  if (await file.length() > 5 * 1024 * 1024) {
    throw const FormatException('Backup-Datei ist zu groß (maximal 5 MB).');
  }
  return decodeRecipeBackup(await file.readAsString());
}
