import 'package:shared_preferences/shared_preferences.dart';
import 'recipe.dart';

/// Prototype-only local persistence.
/// Android and browser storage are INDEPENDENT. There is NO NAS sync yet.
class RecipeStore {
  static const _key = 'rezept_app_recipes_v1';

  Future<List<Recipe>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_key);
    if (saved == null) {
      final initial = <Recipe>[Recipe.schinkenKaeseToast];
      await prefs.setString(_key, encodeRecipes(initial));
      return initial;
    }
    // If decoding fails, do not overwrite potentially recoverable data.
    return decodeRecipes(saved);
  }

  Future<void> save(List<Recipe> recipes) async {
    final prefs = await SharedPreferences.getInstance();
    final ok = await prefs.setString(_key, encodeRecipes(recipes));
    if (!ok) {
      throw StateError('Rezepte konnten nicht lokal gespeichert werden.');
    }
  }
}
