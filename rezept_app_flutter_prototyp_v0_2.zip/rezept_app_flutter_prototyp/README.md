# Rezept-App – Flutter-Prototyp 0.2

Erster **lauffähig angelegter** Flutter-Quellcode für die manuelle Rezeptverwaltung auf Android und Web. Enthält das bestätigte Beispielrezept **Schinken-Käse-Toast**:

- 1 Portion = 2 fertige Toasts
- Toastbrot: 150 g, 4 Scheiben (American Sandwich)
- Gouda: 80 g (S-Budget)
- Toastschinken: 70 g (Tann)
- Gesamt der Zutaten mit Grammangaben: 300 g
- 722 kcal/Portion, gemäß Nutzerscreenshot
- Zubereitung und Kochzeit sind **nicht erfunden**, sondern zunächst leer.

## Datensicherung (neu in 0.2)

- Oben rechts auf das Backup-Symbol tippen: **Backup exportieren** lädt eine JSON-Datei herunter.
- **Backup importieren** wählt eine solche JSON-Datei. Die App prüft die Datei vor dem Import.
- Erst nach ausdrücklicher Bestätigung werden die lokalen Rezepte vollständig ersetzt.
- Das ist ein manuelles Backup, **keine automatische Sicherung und keine Synchronisierung**.
- Browserdaten vor dem ersten Export nicht löschen. Exportierte JSON-Dateien privat aufbewahren (sie enthalten deine Rezepte).

## Funktionen dieses Prototyps

- Rezeptliste und Suchfeld
- Rezept anlegen, bearbeiten, löschen
- Zutaten mit Lebensmittelname und optionalem Kaufprodukt/Marke eingeben
- g / ml / Stück, zusätzlich optionale Stückzahl (z. B. 4 Scheiben = 150 g)
- Portionszahl im Detail ändern; alle Mengen passen sich an
- Mahlzeitenkategorie, Kalorien, Zeit, Meal-Prep- und Einfrierangabe
- Speicherung **nur lokal pro Gerät/Browser** mit `shared_preferences`, zusätzlich manuelle JSON-Sicherung
- Android- und Web-Oberfläche aus derselben Flutter-Codebasis

## Nicht enthalten (noch nicht anschließen oder als fertig betrachten)

- Keine PostgreSQL-/Synology-Anbindung und keine Synchronisierung zwischen Browser/Android
- Keine echte SQLite-Datenbank auf Android; `shared_preferences` ist lediglich eine Prototyp-Speicherung
- Keine Vorratsbuchungen, fertigen Portionen oder Einkaufslisten
- Keine OCR, kein automatischer Wochenplan, keine KI
- Keine Anmeldung und kein Multiuser-Zugriff

## Voraussetzungen

Flutter SDK >= 3.24 (Dart >= 3.4), Android Studio oder ein Android-Gerät mit Debugging, optional Chrome für Web. Die komplette Flutter-Plattformstruktur (`android/`, `web/`, ... ) wird erst durch `flutter create` generiert.

## Start auf einem Rechner mit Flutter SDK

```bash
# 1. ZIP entpacken und in den Projektordner wechseln
cd rezept_app_flutter_prototyp

# 2. Plattformdateien generieren (vorhandene lib-Dateien beibehalten)
flutter create --project-name rezept_app --platforms=android,web .

# 3. Pakete laden und testen
flutter pub get
flutter test

# 4a. Web-App lokal starten
flutter run -d chrome

# 4b. Geräte anzeigen und auf Android starten
flutter devices
flutter run -d <android-geraete-id>
```

`flutter create` benötigt eine reguläre Flutter-Installation. Dieses Archiv enthält bewusst keine großen generierten Android-Gradle-Dateien oder Plattform-Binaries.

## Nächste technische Arbeit

1. Migrationsfähiges Datenmodell für `recipes`, `ingredients` und `recipe_ingredients` verwenden (siehe vorheriger SQL-Entwurf).
2. FastAPI-CRUD auf der Synology einrichten.
3. Flutter-Datenzugriff von `RecipeStore` auf API + Android-SQLite umstellen.
4. Eindeutige IDs und Revisions-/Sync-Operationen für die Mehrgeräte-Synchronisation implementieren.
5. Erst danach Kochvorgänge, Zutatenabbuchung und Fertiggerichtbestände implementieren.

**Hinweis:** Der Code wurde in einer Umgebung ohne Flutter SDK erstellt und konnte dort noch nicht kompiliert oder als Android-App getestet werden. Die enthaltenen Tests sind vorbereitet, aber nicht ausgeführt.
