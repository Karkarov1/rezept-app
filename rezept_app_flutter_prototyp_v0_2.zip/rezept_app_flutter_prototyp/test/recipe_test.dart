import 'package:flutter_test/flutter_test.dart';
import 'package:rezept_app/recipe.dart';

void main() {
  test('Toast sample has one serving, two toasts, 300g and 722 kcal', () {
    final r = Recipe.schinkenKaeseToast;
    expect(r.basePortions, 1);
    expect(r.itemsPerPortion, 2);
    expect(r.caloriesPerPortion, 722);
    expect(r.totalBaseWeightGrams, 300);
    expect(r.ingredients.first.pieces, 4);
  });

  test('Recipe JSON storage round trip preserves ingredient detail', () {
    final serialized = encodeRecipes([Recipe.schinkenKaeseToast]);
    final read = decodeRecipes(serialized);
    expect(read, hasLength(1));
    expect(read.first.ingredients.first.productName, contains('American Sandwich'));
    expect(read.first.ingredients.first.pieceUnit, 'Scheiben');
  });

  test('Scaling by portions uses base portion count', () {
    final recipe = Recipe.schinkenKaeseToast;
    final factor = 2 / recipe.basePortions;
    expect(recipe.ingredients[0].amount * factor, 300);
    expect(recipe.ingredients[1].amount * factor, 160);
    expect(recipe.ingredients[2].amount * factor, 140);
  });
}
