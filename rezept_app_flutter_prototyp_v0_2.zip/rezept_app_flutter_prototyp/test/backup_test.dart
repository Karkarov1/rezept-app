import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:rezept_app/backup.dart';
import 'package:rezept_app/recipe.dart';

void main() {
  test('Backup roundtrip preserves all recipe values', () {
    final sample = Recipe.schinkenKaeseToast;
    final text = encodeRecipeBackup([sample], exportedAt: DateTime.utc(2026, 10, 11));
    final decoded = decodeRecipeBackup(text);
    expect(decoded, hasLength(1));
    expect(decoded.single.toJson(), equals(sample.toJson()));
    expect(decoded.single.ingredients.first.pieces, 4);
    expect(decoded.single.caloriesPerPortion, 722);
    expect(jsonDecode(text)['schemaVersion'], 1);
  });

  test('Rejects unsupported or corrupt backup without saving it', () {
    expect(() => decodeRecipeBackup('[]'), throwsFormatException);
    expect(() => decodeRecipeBackup('{this is not valid JSON'), throwsFormatException);
    expect(
      () => decodeRecipeBackup(jsonEncode({
        'format': 'rezept-app-backup',
        'schemaVersion': 2,
        'recipes': [],
      })),
      throwsFormatException,
    );
  });

  test('Rejects duplicate IDs and invalid quantities', () {
    final r = Recipe.schinkenKaeseToast.toJson();
    expect(
      () => decodeRecipeBackup(jsonEncode({
        'format': 'rezept-app-backup',
        'schemaVersion': 1,
        'recipes': [r, r],
      })),
      throwsFormatException,
    );
    final invalid = Map<String, dynamic>.from(r)..['basePortions'] = 0;
    expect(
      () => decodeRecipeBackup(jsonEncode({
        'format': 'rezept-app-backup',
        'schemaVersion': 1,
        'recipes': [invalid],
      })),
      throwsFormatException,
    );
  });
}
