import 'dart:convert';

import 'recipe.dart';

/// Conservative first-time sync: never replace or delete existing recipes.
/// Edits to the same ID are conflicts until explicit conflict handling exists.
class SyncPlan {
  const SyncPlan({
    required this.toUpload,
    required this.toDownload,
    required this.conflicts,
    required this.unchanged,
  });

  final List<Recipe> toUpload;
  final List<Recipe> toDownload;
  final List<String> conflicts;
  final int unchanged;
}

SyncPlan buildSyncPlan(List<Recipe> local, List<Recipe> remote) {
  final localById = {for (final recipe in local) recipe.id: recipe};
  final remoteById = {for (final recipe in remote) recipe.id: recipe};
  final toUpload = <Recipe>[];
  final toDownload = <Recipe>[];
  final conflicts = <String>[];
  var unchanged = 0;

  for (final recipe in local) {
    final onServer = remoteById[recipe.id];
    if (onServer == null) {
      toUpload.add(recipe);
    } else if (jsonEncode(recipe.toJson()) == jsonEncode(onServer.toJson())) {
      unchanged++;
    } else {
      conflicts.add(recipe.title);
    }
  }
  for (final recipe in remote) {
    if (!localById.containsKey(recipe.id)) toDownload.add(recipe);
  }
  return SyncPlan(
    toUpload: toUpload,
    toDownload: toDownload,
    conflicts: conflicts,
    unchanged: unchanged,
  );
}
