import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'nas_api.dart';
import 'recipe.dart';
import 'sync_plan.dart';

/// Safe, manual first transfer. Nothing is overwritten or deleted remotely.
class NasSyncPage extends StatefulWidget {
  const NasSyncPage({
    super.key,
    required this.localRecipes,
    required this.onImportMissing,
  });

  final List<Recipe> localRecipes;
  final Future<void> Function(List<Recipe>) onImportMissing;

  @override
  State<NasSyncPage> createState() => _NasSyncPageState();
}

class _NasSyncPageState extends State<NasSyncPage> {
  static const _urlKey = 'rezept_app_nas_url_v1';
  final _address = TextEditingController();
  final _username = TextEditingController();
  final _password = TextEditingController();
  NasApiClient? _api;
  SyncPlan? _plan;
  bool _busy = false;
  String? _signedInAs;
  String? _message;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _loadAddress();
  }

  Future<void> _loadAddress() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted && _address.text.isEmpty) {
      _address.text = prefs.getString(_urlKey) ?? '';
    }
  }

  @override
  void dispose() {
    _address.dispose();
    _username.dispose();
    _password.dispose();
    _api?.close();
    super.dispose();
  }

  void _notice(String message, {bool error = false}) {
    if (!mounted) return;
    setState(() {
      _message = message;
      _failed = error;
    });
  }

  Future<void> _login() async {
    if (_busy) return;
    setState(() { _busy = true; _message = null; });
    NasApiClient? candidate;
    try {
      final api = NasApiClient(_address.text);
      candidate = api;
      await api.checkConnection();
      final account = await api.login(_username.text, _password.text);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_urlKey, _address.text.trim());
      _password.clear();
      if (!mounted) return;
      _api?.close();
      setState(() {
        _api = api;
        _signedInAs = account;
        _plan = null;
      });
      candidate = null;
      _notice('Angemeldet als $account. Jetzt NAS-Rezepte vergleichen.');
    } catch (error) {
      _notice('Verbindung fehlgeschlagen: $error', error: true);
    } finally {
      candidate?.close();
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _preview() async {
    final api = _api;
    if (api == null || _busy) return;
    setState(() { _busy = true; _message = null; _plan = null; });
    try {
      final remote = await api.getRecipes();
      // Backend v0.4 limits responses to 500 recipes; prevent incomplete merges.
      if (remote.length >= 500) {
        throw const NasApiException('NAS-Liste hat das Limit von 500 Rezepten erreicht. Kein Abgleich möglich.');
      }
      final plan = buildSyncPlan(widget.localRecipes, remote);
      if (mounted) setState(() => _plan = plan);
      _notice('Vergleich abgeschlossen. Noch wurden keine Rezepte übertragen.');
    } catch (error) {
      _notice('Vergleich fehlgeschlagen: $error', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _transfer() async {
    final plan = _plan;
    final api = _api;
    if (plan == null || api == null || _busy) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Rezepte übertragen?'),
        content: Text(
          '${plan.toUpload.length} lokale Rezepte werden auf die NAS kopiert. '
          '${plan.toDownload.length} Rezepte werden von der NAS lokal ergänzt. '
          '${plan.conflicts.length} Konflikte bleiben unverändert. '
          'Es wird nichts gelöscht oder überschrieben. '
          'Bitte vorher ein aktuelles JSON-Backup erstellen.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Abbrechen')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Übertragen')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() { _busy = true; _message = null; });
    var uploaded = 0;
    try {
      for (final recipe in plan.toUpload) {
        await api.createRecipe(recipe);
        uploaded++;
      }
      // Refetch after uploading, so a concurrent NAS change cannot be
      // imported using an older preview snapshot.
      final latestRemote = await api.getRecipes();
      if (latestRemote.length >= 500) {
        throw const NasApiException('NAS-Rezeptlimit erreicht; Download abgebrochen.');
      }
      final updatedPlan = buildSyncPlan(widget.localRecipes, latestRemote);
      if (updatedPlan.toDownload.isNotEmpty) {
        await widget.onImportMissing(updatedPlan.toDownload);
      }
      if (!mounted) return;
      setState(() => _plan = null);
      _notice('Übertragung abgeschlossen: $uploaded zur NAS, '
          '${updatedPlan.toDownload.length} aufs Gerät. '
          '${updatedPlan.conflicts.length} Konflikte wurden nicht verändert.');
    } catch (error) {
      _notice('Übertragung unterbrochen (bereits $uploaded Rezepte zur NAS übertragen). '
          'Keine vorhandenen Daten überschrieben. Bitte erneut vergleichen. Fehler: $error', error: true);
      if (mounted) setState(() => _plan = null);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _logout() async {
    final api = _api;
    if (api == null || _busy) return;
    setState(() => _busy = true);
    try {
      await api.logout();
    } catch (_) {
      // Token is still discarded locally, even if NAS is temporarily offline.
    } finally {
      api.close();
      if (mounted) {
        setState(() { _api = null; _signedInAs = null; _plan = null; _busy = false; });
        _notice('Abgemeldet.');
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Synology-Abgleich')),
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 640),
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Text('Erster sicherer Abgleich', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                const Text('Tailscale muss auf diesem Gerät verbunden sein. '
                    'Bestehende Rezepte werden bei diesem ersten Abgleich nicht überschrieben oder gelöscht. '
                    'Automatischer Hintergrund-Abgleich folgt in einer späteren Version.'),
                const SizedBox(height: 20),
                if (_signedInAs == null) ...[
                  TextField(
                    controller: _address,
                    keyboardType: TextInputType.url,
                    autocorrect: false,
                    decoration: const InputDecoration(labelText: 'NAS-Adresse (HTTPS)',
                        hintText: 'https://deine-nas.dein-netz.ts.net'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _username,
                    autocorrect: false,
                    decoration: const InputDecoration(labelText: 'Benutzername'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _password,
                    obscureText: true,
                    decoration: const InputDecoration(labelText: 'Passwort'),
                    onSubmitted: (_) => _login(),
                  ),
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    onPressed: _busy ? null : _login,
                    icon: const Icon(Icons.login),
                    label: const Text('Mit NAS verbinden und anmelden'),
                  ),
                ] else ...[
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.verified_user_outlined),
                    title: Text('Angemeldet: $_signedInAs'),
                    subtitle: Text(_address.text),
                    trailing: TextButton(onPressed: _busy ? null : _logout, child: const Text('Abmelden')),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _busy ? null : _preview,
                    icon: const Icon(Icons.compare_arrows),
                    label: const Text('Rezepte vergleichen'),
                  ),
                  if (_plan != null) ...[
                    const SizedBox(height: 18),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('${_plan!.toUpload.length} nur auf diesem Gerät'),
                            Text('${_plan!.toDownload.length} nur auf der NAS'),
                            Text('${_plan!.unchanged} identische Rezepte'),
                            Text('${_plan!.conflicts.length} Konflikte (unverändert lassen)'),
                            if (_plan!.conflicts.isNotEmpty) ...[
                              const SizedBox(height: 10),
                              Text('Konflikte: ${_plan!.conflicts.take(10).join(', ')}'),
                            ],
                            const SizedBox(height: 16),
                            FilledButton.icon(
                              onPressed: _busy || (_plan!.toUpload.isEmpty && _plan!.toDownload.isEmpty)
                                  ? null : _transfer,
                              icon: const Icon(Icons.sync),
                              label: const Text('Fehlende Rezepte übertragen'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ],
                if (_busy) ...[
                  const SizedBox(height: 16),
                  const LinearProgressIndicator(),
                ],
                if (_message != null) ...[
                  const SizedBox(height: 16),
                  Text(_message!, style: TextStyle(color: _failed ? Theme.of(context).colorScheme.error : null)),
                ],
                const SizedBox(height: 24),
                const Text('Wichtig: Neue Bearbeitungen und Löschungen werden in dieser Version '
                    'noch nicht automatisch synchronisiert. Vor dem Gerätwechsel erneut vergleichen. '
                    'Deine lokalen Rezepte und der JSON-Export bleiben erhalten.',
                    style: TextStyle(fontSize: 12)),
              ],
            ),
          ),
        ),
      );

}
