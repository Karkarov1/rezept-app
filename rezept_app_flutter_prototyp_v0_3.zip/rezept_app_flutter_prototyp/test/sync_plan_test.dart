import 'package:flutter_test/flutter_test.dart';
import 'package:rezept_app/recipe.dart';
import 'package:rezept_app/sync_plan.dart';

Recipe sample(String id, String title) => Recipe(
      id: id,
      title: title,
      category: 'Mittagessen',
      basePortions: 2,
      ingredients: const [IngredientLine(foodName: 'Nudeln', amount: 200, unit: 'g')],
    );

void main() {
  test('New local recipe uploads without deletion', () {
    final plan = buildSyncPlan([sample('a', 'A')], []);
    expect(plan.toUpload.length, 1);
    expect(plan.toDownload, isEmpty);
    expect(plan.conflicts, isEmpty);
  });

  test('Remote-only recipe downloaded', () {
    final plan = buildSyncPlan([], [sample('b', 'B')]);
    expect(plan.toUpload, isEmpty);
    expect(plan.toDownload.single.id, 'b');
  });

  test('Same-ID different content never overwritten', () {
    final plan = buildSyncPlan([sample('a', 'local')], [sample('a', 'remote')]);
    expect(plan.toUpload, isEmpty);
    expect(plan.toDownload, isEmpty);
    expect(plan.conflicts, ['local']);
  });

  test('Identical recipes recognized', () {
    final plan = buildSyncPlan([sample('a', 'A')], [sample('a', 'A')]);
    expect(plan.unchanged, 1);
    expect(plan.toUpload, isEmpty);
    expect(plan.toDownload, isEmpty);
    expect(plan.conflicts, isEmpty);
  });
}
