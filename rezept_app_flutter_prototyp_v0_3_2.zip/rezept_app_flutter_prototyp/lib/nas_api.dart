import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'recipe.dart';

class NasApiException implements Exception {
  const NasApiException(this.message);
  final String message;

  @override
  String toString() => message;
}

/// The user's short-lived, revocable session token is held in memory here.
/// NasSyncEngine can persist it per device; NEVER store the NAS API_TOKEN.
class NasApiClient {
  NasApiClient(String address)
      : _root = _validatedAddress(address),
        _client = http.Client();

  final Uri _root;
  final http.Client _client;
  String? _token;
  DateTime? tokenExpiresAt;
  String? get token => _token;

  void restoreToken(String token) {
    if (token.isEmpty) throw const NasApiException('Leerer Sitzungsschlüssel.');
    _token = token;
  }

  Future<String> verifySession() async {
    final response = await _send('GET', '/auth/me');
    final data = jsonDecode(response.body);
    if (data is! Map || data['username'] is! String) {
      throw const NasApiException('Unerwartete Antwort bei der Sitzungsprüfung.');
    }
    return data['username'] as String;
  }


  static Uri _validatedAddress(String input) {
    final uri = Uri.tryParse(input.trim());
    if (uri == null ||
        uri.scheme != 'https' ||
        uri.host.isEmpty ||
        uri.userInfo.isNotEmpty ||
        uri.hasQuery ||
        uri.hasFragment ||
        (uri.path.isNotEmpty && uri.path != '/')) {
      throw const NasApiException('Bitte eine HTTPS-Serveradresse ohne Pfad eingeben.');
    }
    return uri.replace(path: '/');
  }

  Uri _endpoint(String path) => _root.resolve(path);

  Future<http.Response> _send(String method, String path, {Object? jsonBody}) async {
    final headers = <String, String>{'Accept': 'application/json'};
    if (jsonBody != null) headers['Content-Type'] = 'application/json';
    if (_token != null) headers['Authorization'] = 'Bearer $_token';
    try {
      final request = http.Request(method, _endpoint(path));
      request.headers.addAll(headers);
      if (jsonBody != null) request.body = jsonEncode(jsonBody);
      final response = await http.Response.fromStream(
        await _client.send(request).timeout(const Duration(seconds: 20)),
      ).timeout(const Duration(seconds: 20));
      if (response.statusCode == 401) {
        throw const NasApiException('Anmeldung ungültig oder abgelaufen. Bitte erneut anmelden.');
      }
      if (response.statusCode >= 400) {
        switch (response.statusCode) {
          case 409:
            throw const NasApiException('Rezeptkonflikt auf der NAS. Keine Daten überschrieben.');
          case 422:
            throw const NasApiException('Ein Rezept enthält ungültige Angaben.');
          case 503:
            throw const NasApiException('Datenbank auf der NAS nicht verfügbar.');
          default:
            throw NasApiException('NAS hat HTTP ${response.statusCode} zurückgemeldet.');
        }
      }
      return response;
    } on TimeoutException {
      throw const NasApiException('Zeitüberschreitung. Ist Tailscale verbunden?');
    } on http.ClientException {
      throw const NasApiException('NAS nicht erreichbar. Tailscale und Adresse prüfen.');
    }
  }

  Future<void> checkConnection() async {
    final response = await _send('GET', '/health/db');
    final data = jsonDecode(response.body);
    if (data is! Map || data['database'] != 'connected') {
      throw const NasApiException('Die NAS-Datenbank meldet keinen erfolgreichen Status.');
    }
  }

  Future<String> login(String username, String password) async {
    if (username.trim().isEmpty || password.isEmpty) {
      throw const NasApiException('Benutzername und Passwort erforderlich.');
    }
    try {
      final response = await _send('POST', '/auth/login', jsonBody: {
        'username': username.trim(),
        'password': password,
      });
      final data = jsonDecode(response.body);
      if (data is! Map || data['accessToken'] is! String) {
        throw const NasApiException('Unerwartete Antwort bei der Anmeldung.');
      }
      _token = data['accessToken'] as String;
      tokenExpiresAt = DateTime.tryParse(data['expiresAt'] as String? ?? '');
      return data['username'] as String? ?? username.trim();
    } on NasApiException catch (e) {
      if (e.message.contains('401') || e.message.contains('ungültig')) {
        throw const NasApiException('Anmeldung fehlgeschlagen. Benutzername oder Passwort prüfen.');
      }
      rethrow;
    }
  }

  Future<List<Recipe>> getRecipes() async {
    final response = await _send('GET', '/recipes');
    final decoded = jsonDecode(response.body);
    if (decoded is! List) throw const NasApiException('Ungültiges Rezeptformat von der NAS.');
    return decoded.map((item) => Recipe.fromJson(item as Map<String, dynamic>)).toList();
  }

  Future<Recipe> createRecipe(Recipe recipe) async {
    final response = await _send('POST', '/recipes', jsonBody: recipe.toJson());
    if (response.statusCode != 201) {
      throw NasApiException('Unerwarteter Speicherstatus: ${response.statusCode}.');
    }
    return Recipe.fromJson(jsonDecode(response.body) as Map<String, dynamic>);
  }

  Future<Recipe> updateRecipe(Recipe recipe, int expectedRevision) async {
    if (expectedRevision < 1) throw const NasApiException('NAS-Revisionsnummer fehlt.');
    final headers = <String,String>{
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'If-Match': expectedRevision.toString(),
      'Authorization': 'Bearer $_token',
    };
    try {
      final response = await http.put(_endpoint('/recipes/${Uri.encodeComponent(recipe.id)}'),
          headers: headers, body: jsonEncode(recipe.toJson())).timeout(const Duration(seconds: 20));
      if (response.statusCode == 409) {
        throw const NasApiException('Die NAS-Version wurde zwischenzeitlich geändert. Bitte erneut vergleichen.');
      }
      if (response.statusCode == 401) {
        throw const NasApiException('Anmeldung abgelaufen. Bitte erneut anmelden.');
      }
      if (response.statusCode != 200) {
        throw NasApiException('NAS-Update fehlgeschlagen: HTTP ${response.statusCode}.');
      }
      return Recipe.fromJson(jsonDecode(response.body) as Map<String, dynamic>);
    } on TimeoutException {
      throw const NasApiException('Zeitüberschreitung beim Aktualisieren. Bitte erneut vergleichen.');
    } on http.ClientException {
      throw const NasApiException('NAS nicht erreichbar. Änderung bleibt lokal gespeichert.');
    }
  }

  Future<void> logout() async {
    if (_token == null) return;
    try {
      await _send('POST', '/auth/logout');
    } finally {
      _token = null;
    }
  }

  void close() {
    _token = null;
    _client.close();
  }
}
